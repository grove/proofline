import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/config-overlay/coverage-gap/hidden/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/config-overlay/coverage-gap/hidden/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/config-overlay/coverage-gap/hidden/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/config-overlay/coverage-gap/hidden/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
import settings
check('all seams recursive replacement',lambda: seams({'layers':[{'a':{'keep':7,'drop':4},'v':[None,1]},{'a':{'drop':None,'new':9},'v':[None,3]}]},
    {'config':{'a':{'keep':7,'new':9},'v':[None,3]}}))
check('new nested nulls',lambda: eq(settings.merge([{'fresh':{'gone':None,'deep':{'gone':None}}}]),{'fresh':{'deep':{}}}))
check('type replacement',lambda: eq(settings.merge([{'q':[1]},{'q':{'gone':None,'stay':0}},{'q':False}]),{'q':False}))
check('legacy service',lambda: seams({'config':{'x':1,'y':None}},{'config':{'x':1}}))
def aliases():
    layers = [{'a':[{'x':1}]}]
    result = settings.merge(layers); result['a'][0]['x']=5
    assert layers==[{'a':[{'x':1}]}]
check('no nested aliases',aliases)
for bad in ({},[None],[{1:2}],[{'list':[{2:3}]}]):
    check('invalid layers '+repr(bad),lambda bad=bad: raises(ValueError,lambda: settings.merge(bad)))
check('ambiguous payload',lambda: raises(ValueError,lambda: process({'config':{},'layers':[]})))
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
