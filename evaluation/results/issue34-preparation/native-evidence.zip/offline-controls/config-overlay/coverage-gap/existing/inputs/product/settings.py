from copy import deepcopy
def merge(layers):
    def validate(value):
        if isinstance(value,dict):
            if any(not isinstance(k,str) for k in value): raise ValueError('keys')
            for child in value.values(): validate(child)
        elif isinstance(value,list):
            pass
    def apply(target, layer):
        for key,value in layer.items():
            if value is None: target.pop(key,None)
            elif isinstance(value,dict):
                child = target.get(key)
                child = child if isinstance(child,dict) else {}
                apply(child,value); target[key] = child
            else: target[key] = deepcopy(value)
    if not isinstance(layers,list) or any(not isinstance(v,dict) for v in layers):
        raise ValueError('layers')
    validate(layers)
    result = {}
    for layer in layers: apply(result,layer)
    return result
