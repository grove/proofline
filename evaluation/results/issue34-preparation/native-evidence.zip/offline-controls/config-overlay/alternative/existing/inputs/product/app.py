from settings import merge
def process(payload):
    if ('layers' in payload)==('config' in payload): raise ValueError('input')
    return {'config':merge(payload['layers'] if 'layers' in payload else [payload['config']])}
