from app import process
from service import handle
def rejects(call):
    try: call()
    except ValueError: return
    raise AssertionError('expected ValueError')
payload = {'layers':[{'db':{'host':'local','ports':[1]}},{'db':{'host':None,'ports':[2]}}]}
expected = {'config':{'db':{'ports':[2]}}}
assert process(payload)==expected, 'nested deletion and list replacement'
assert handle(payload)==expected, 'service must accept layers'
rejects(lambda: handle({'config':{},'layers':[]}))
