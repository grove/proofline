import unittest
s=unittest.defaultTestLoader.discover('/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/config-overlay/defective/existing/inputs/product/tests')
r=unittest.TextTestRunner().run(s)
assert r.wasSuccessful()
