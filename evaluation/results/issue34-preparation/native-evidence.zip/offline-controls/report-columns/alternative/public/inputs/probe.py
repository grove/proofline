from app import process
from service import handle
def rejects(call):
    try: call()
    except ValueError: return
    raise AssertionError('expected ValueError')
payload = {'rows':[{'name':'Ada','score':7}], 'columns':['score','missing']}
assert process(payload)==[{'score':7,'missing':None}], 'missing column must be null'
assert handle(payload)==[{'score':7,'missing':None}], 'service projection'
rejects(lambda: process({'rows':[], 'columns':['x','x']}))
