from copy import deepcopy
def project(rows, columns=None):
    if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):
        raise ValueError('rows')
    if columns is not None and (not isinstance(columns,list) or
            any(not isinstance(c,str) or not c for c in columns) or len(set(columns))!=len(columns)):
        raise ValueError('columns')
    result = []
    for row in rows:
        projected = {}
        for key in (row if columns is None else columns): projected[key] = deepcopy(row.get(key))
        result.append(projected)
    return result
