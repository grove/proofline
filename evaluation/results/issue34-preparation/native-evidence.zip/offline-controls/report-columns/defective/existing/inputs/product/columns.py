from copy import deepcopy
def project(rows, columns=None):
    if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):
        raise ValueError('rows')
    if columns is not None and (not isinstance(columns,list) or
            any(not isinstance(c,str) or not c for c in columns) or len(set(columns))!=len(columns)):
        raise ValueError('columns')
    return deepcopy(rows if columns is None else [{c:r[c] for c in columns if c in r} for r in rows])
