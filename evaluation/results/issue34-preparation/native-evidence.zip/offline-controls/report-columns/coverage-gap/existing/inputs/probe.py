import unittest
s=unittest.defaultTestLoader.discover('/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/report-columns/coverage-gap/existing/inputs/product/tests')
r=unittest.TextTestRunner().run(s)
assert r.wasSuccessful()
