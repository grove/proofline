import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/atomic-export/reference/hidden/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/atomic-export/reference/hidden/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/atomic-export/reference/hidden/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/atomic-export/reference/hidden/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
import exporter
check('all seams missing append separator',lambda: seams({'previous':'header','records':[{'c':8}],'append':True},
    {'text':'header\n{"c": 8}\n','count':1}))
check('all seams append newline',lambda: seams({'previous':'{"old": 1}\n','records':[{'b':'雪','a':2}],'append':True},
    {'text':'{"old": 1}\n{"a": 2, "b": "雪"}\n','count':1}))
def atomicity():
    with tempfile.TemporaryDirectory(dir='.') as folder:
        path=Path(folder)/'data'
        def unchanged(call,kind=ValueError):
            path.write_bytes(b'original\xff')
            raises(kind,call)
            assert path.read_bytes()==b'original\xff'
            assert sorted(p.name for p in Path(folder).iterdir())==['data']
        for bad in ([],{'x':float('inf')},{'x':object()}):
            unchanged(lambda: exporter.write_records(path,iter([{'ok':1},bad])))
        def broken():
            yield {'ok':2}; raise RuntimeError('iteration')
        unchanged(lambda: exporter.write_records(path,broken()),RuntimeError)
        reject_replace = [True]
        def audit(event,args):
            if reject_replace[0] and event=='os.rename': raise OSError('replace')
        sys.addaudithook(audit)
        try: unchanged(lambda: exporter.write_records(path,[{'ok':3}]),OSError)
        finally: reject_replace[0] = False
        path.unlink()
        raises(ValueError,lambda: exporter.write_records(path,[None]))
        assert list(Path(folder).iterdir())==[]
        path.write_bytes(b'unchanged')
        assert exporter.write_records(path,[],append=True)==0 and path.read_bytes()==b'unchanged'
        path.unlink()
        assert exporter.write_records(path,iter([{'x':1}]),append=True)==1
        assert path.read_bytes()==b'{"x": 1}\n'
check('rollback, replace failure, cleanup and missing append',atomicity)
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
