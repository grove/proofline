import json, os, tempfile
from pathlib import Path
def write_records(path, records, *, append=False):
    path = Path(path); temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,delete=False,mode='wb') as stream:
            temporary = Path(stream.name)
            previous = path.read_bytes() if append and path.exists() else b''
            stream.write(previous); count = 0
            for record in records:
                if not isinstance(record,dict): raise ValueError('record')
                try: line = json.dumps(record,sort_keys=True,ensure_ascii=False,allow_nan=False).encode('utf-8')+b'\n'
                except (TypeError,ValueError,UnicodeError) as error: raise ValueError('record') from error
                if count==0 and previous and not previous.endswith(b'\n'): stream.write(b'\n')
                stream.write(line); count += 1
            stream.flush()
        os.replace(temporary,path); temporary = None
        return count
    finally:
        if temporary is not None: temporary.unlink(missing_ok=True)
