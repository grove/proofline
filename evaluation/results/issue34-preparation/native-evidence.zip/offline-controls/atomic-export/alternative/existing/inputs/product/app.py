from pathlib import Path
import tempfile
from exporter import write_records
def process(payload):
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/'out.jsonl'
        if 'previous' in payload: path.write_text(payload['previous'],encoding='utf-8')
        count = write_records(path,payload['records'],append=payload.get('append',False))
        return {'text':path.read_text(encoding='utf-8'),'count':count}
