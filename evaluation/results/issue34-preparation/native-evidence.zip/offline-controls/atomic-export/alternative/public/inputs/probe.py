from app import process
from service import handle
def rejects(call):
    try: call()
    except ValueError: return
    raise AssertionError('expected ValueError')
payload = {'previous':'old','records':[{'z':'ø'}],'append':True}
expected = {'text':'old\n{"z": "ø"}\n','count':1}
assert process(payload)==expected, 'append separator and UTF-8'
assert handle(payload)==expected, 'service append'
rejects(lambda: process({'records':[float('nan')]}))
