import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/cache-expiry/defective/hidden/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/cache-expiry/defective/hidden/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/cache-expiry/defective/hidden/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/offline-controls/cache-expiry/defective/hidden/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
from cache import Cache
check('action seams',lambda: seams({'actions':[{'op':'get','key':'z','value':4,'at':3,'ttl':0},
    {'op':'get','key':'z','value':6,'at':3,'ttl':0},{'op':'invalidate','key':'z'},{'op':'invalidate','key':'z'},{'op':'clear'}]},
    {'values':[4,6,True,False,0],'loads':2}))
def temporal():
    now=[10]; calls=[]; cache=Cache(lambda:now[0])
    def loader(): calls.append(1); return {'a':[1]}
    one=cache.get('k',loader,2); one['a'].append(3)
    now[0]=11; two=cache.get('k',loader); assert two=={'a':[1]} and len(calls)==1
    two['a'].append(4); assert cache.get('k',loader)=={'a':[1]}
    now[0]=12; cache.get('k',loader,2); assert len(calls)==2
    now[0]=99; assert cache.invalidate('k') is True
    assert cache.clear()==0
    cache.get('infinite',loader); now[0]=1e6
    cache.get('infinite',loader); assert len(calls)==3
check('time, hit validation and aliases',temporal)
def invalid():
    cache=Cache(lambda:0); cache.get('hit',lambda:1)
    for ttl in (True,-1,float('nan'),float('inf'),'2'):
        raises(ValueError,lambda: cache.get('hit',lambda:2,ttl))
    raises(RuntimeError,lambda: cache.get('fail',lambda: (_ for _ in ()).throw(RuntimeError())))
    assert cache.invalidate('fail') is False
    assert cache.get('fail',lambda:9)==9
check('invalid ttl and loader failure',invalid)
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
