from cache import Cache
def process(payload):
    now = [0]; loads = []; values = []
    cache = Cache(lambda: now[0])
    for action in payload['actions']:
        if action['op']=='clear':
            values.append(cache.clear()); continue
        if action['op']=='invalidate':
            values.append(cache.invalidate(action['key'])); continue
        if action['op']!='get': raise ValueError('op')
        now[0] = action.get('at',0)
        def loader():
            loads.append(1)
            return action['value']
        values.append(cache.get(action['key'],loader,action.get('ttl')))
    return {'values':values,'loads':len(loads)}
