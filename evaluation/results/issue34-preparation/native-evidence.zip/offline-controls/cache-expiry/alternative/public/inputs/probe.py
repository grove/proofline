from app import process
from service import handle
def rejects(call):
    try: call()
    except ValueError: return
    raise AssertionError('expected ValueError')
payload = {'actions':[{'op':'get','key':'x','value':1,'at':0,'ttl':2},
    {'op':'get','key':'x','value':2,'at':2,'ttl':2},{'op':'clear'}]}
assert process(payload)=={'values':[1,2,1],'loads':2}, 'expiry at boundary and clear'
assert handle(payload)=={'values':[1,2,1],'loads':2}, 'service cache actions'
