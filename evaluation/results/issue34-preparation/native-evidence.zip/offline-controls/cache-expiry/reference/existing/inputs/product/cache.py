from copy import deepcopy
import math
class Cache:
    def __init__(self, clock):
        self.clock = clock; self.entries = {}
    def get(self, key, loader, ttl=None):
        if ttl is not None and (type(ttl) not in (int,float) or ttl<0 or not math.isfinite(ttl)):
            raise ValueError('ttl')
        now = self.clock()
        entry = self.entries.get(key)
        if entry is None or (entry[1] is not None and now>=entry[1]):
            value = deepcopy(loader())
            entry = (value,None if ttl is None else self.clock()+ttl)
            self.entries[key] = entry
        return deepcopy(entry[0])
    def invalidate(self, key):
        if key not in self.entries: return False
        del self.entries[key]; return True
    def clear(self):
        count = len(self.entries); self.entries.clear(); return count
