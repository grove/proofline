import json, subprocess, sys
from pathlib import Path
product=Path(sys.path[0])
argv=['/opt/homebrew/Cellar/python@3.14/3.14.8_2/Frameworks/Python.framework/Versions/3.14/bin/python3.14', "-B", "-m", "unittest", *['tests.test_supported_cli']]
receipt={"argv":argv,"cwd":str(product),"exit_code":None,"timed_out":False}
try:
 result=subprocess.run(argv,cwd=product,capture_output=True,text=True,timeout=20)
 receipt.update(exit_code=result.returncode,stdout=result.stdout[:8192],stderr=result.stderr[:8192],
                stdout_truncated=len(result.stdout)>8192,stderr_truncated=len(result.stderr)>8192)
except subprocess.TimeoutExpired:
 receipt["timed_out"]=True
print(json.dumps(receipt))
