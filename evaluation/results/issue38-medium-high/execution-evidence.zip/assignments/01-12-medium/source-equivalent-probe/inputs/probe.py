import io,json,sys,tempfile
from contextlib import redirect_stdout,redirect_stderr
from pathlib import Path
from unittest.mock import patch
import proofline
from checks import local_run
request='Original request:\r\n  Keep Unicode: "José" 🧪\n\n'
commands=[[sys.executable,'-c','print("$HOME; $(touch sentinel); *")']]
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp); source=root/'source.md'; checks=root/'checks.json'
 source.write_bytes(request.encode()); checks.write_text(json.dumps(commands))
 calls=[]
 def record(*a):
  calls.append(a); return {'status':'CHECKS PASSED','assurance':'forwarding only'}
 with redirect_stdout(io.StringIO()),patch.object(local_run,'check',side_effect=record),patch.object(local_run,'run',side_effect=record),patch.object(local_run.live,'launch',side_effect=AssertionError('unexpected model')):
  for mode in ['check','run']:
   common=[mode,'--repo',str(root),'--output',str(root/'out')]
   assert proofline.main(common+['--request',request,'--check-argv',json.dumps(commands[0])])==0
   assert proofline.main(common+['--source',str(source),'--checks',str(checks)])==0
   assert proofline.main(common+['--request-file',str(source),'--check-argv',json.dumps(commands[0])])==0
 assert all(a[1]==request and a[2]==commands for a in calls)
 with redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()) as error,patch.object(local_run,'check',side_effect=ValueError('The supported native boundary is macOS')):
  assert proofline.main(['check','--repo',str(root),'--request',request,'--check-argv',json.dumps(commands[0])])!=0
  assert 'macOS' in error.getvalue()
 with redirect_stdout(io.StringIO()),redirect_stderr(io.StringIO()),patch.object(local_run,'check',side_effect=AssertionError('unexpected call')):
  assert proofline.main(['check','--repo',str(root),'--request',request,'--check-argv','{broken'])!=0
print(json.dumps({'passed':True,'source_bytes_preserved':True,'literal_argv_preserved':True,'direct_file_run_check_equivalent':True,'runtime_error_reported':True,'invalid_json_no_call':True,'model_dispatches':0}))
