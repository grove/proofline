import json,re,shutil,sys,tempfile
from pathlib import Path
product=Path(sys.path[0])
canonical=product/'skills/proofline-check/SKILL.md'
pointer=(product/'SKILL.md').read_text()
assert 'skills/proofline-check/SKILL.md' in pointer
assert 'Use the [supported local runner]' not in pointer
links=[link for link in re.findall(r'\]\(([^)]+)\)',canonical.read_text()) if not link.startswith(('http:','https:','#'))]
assert all((canonical.parent/link).resolve().exists() for link in links)
broken={}
with tempfile.TemporaryDirectory() as temporary:
 root=Path(temporary)
 for host in ('.agents','.claude'):
  installed=root/host/'skills/proofline-check'
  shutil.copytree(canonical.parent,installed)
  broken[host]=[link for link in links if not (installed/link).resolve().exists()]
print(json.dumps({'compatibility_pointer_source_valid':True,'source_layout_links_resolve':True,'documented_copy_install_broken_links':broken,'model_dispatches':0}))
