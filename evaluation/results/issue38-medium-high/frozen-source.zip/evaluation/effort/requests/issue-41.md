Fix Homebrew Python alias mismatch in future-oracle receipts

## Problem observed on an actual PR

The real-world check casebook in [#37 / PR #40](https://github.com/grove/proofline/pull/40) reproduced **10 failed `tests.test_source_oracles` controls on macOS** from merged [#36 / PR #39](https://github.com/grove/proofline/pull/39), although Linux CI was green. A future-only oracle subprocess reported its Python executable through the Homebrew alias `/opt/homebrew/opt/python@3.14/bin/python3.14`; `evaluation/future_cache.py` validates the receipt against the resolved Cellar path. The differing path strings caused `ORACLE UNAVAILABLE` even when the underlying command actually ran.

This is a **receipt identity/portability defect**, not evidence that a cache implementation was wrong. It must be fixed without accepting arbitrary command substitutions or weakening evidence integrity.

## Minimal change

- [ ] In `evaluation/future_cache.py`, make the **actual recorded child invocation** and the **trusted expected argv** agree on an exact, deliberately selected interpreter identity. Prefer invoking the *canonical resolved executable* and continuing to compare the actual receipt's argv exactly, rather than blindly declaring arbitrary paths equivalent after execution.
- [ ] If alias handling is required, qualify equivalence using a clearly defined trusted identity and retain **both the literal executed argv and the resolved identity** in the receipt. An unrelated binary, changed symlink, malicious alias, unexpected argv/cwd, omitted options, or mismatched evidence must remain unavailable.
- [ ] Keep repository-test launch cwd, subprocess exit status, stdout/stderr, timeout and command provenance separately observable from behavioral correctness. A green original suite is **PASSED**, an intentionally red one **FAILED**, and malformed/tampered or unavailable receipts **UNAVAILABLE**, not false product defects.
- [ ] Add focused regressions covering a temporary relative/absolute executable alias where applicable, actual Homebrew alias vs Cellar executable on supported macOS, an unrelated interpreter/changed link, and the existing positive/negative cache/reference controls. Preserve no-follow/protection guarantees.
- [ ] Re-run `python -B -m unittest tests.test_source_oracles -v` and the normal repo suite on the **supported macOS Python 3.14/Codex host**; distinguish this from Linux CI. Retain concise reproducer and before/after results. Never claim the issue fixed based only on passing Linux jobs.

## Boundaries

This is a **small future-oracle fix**, with **zero coding-model calls** and **no new benchmark, dependency, approval process or oracle engine**. Leave frozen #16, #32 and #34 study bytes, scores and receipts unchanged; do not retroactively repair or re-grade published results. Do not relax the original requirement-to-oracle checks or the model-free Proofline check safety boundary.

## Definition of done

The original macOS reproducible `ORACLE UNAVAILABLE` caused solely by the Python alias is gone; valid controls have correct verdicts; adversarial argv and alias mismatches are rejected; native receipts remain exact and auditably bound. Create a small PR with tests; **do not merge without explicit approval**.

**Priority:** Fix before running [#38](https://github.com/grove/proofline/issues/38)'s next model-effort comparison. Reference: [casebook](https://github.com/grove/proofline/blob/main/docs/ISSUE37.md).