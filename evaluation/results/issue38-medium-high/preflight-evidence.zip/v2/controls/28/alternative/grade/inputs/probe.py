import sys
from pathlib import Path
suite_file=Path('private_regressions.py')
suite_file.write_text('"""Packaging observations; equivalent wording/layout is judged by source audit."""\nfrom pathlib import Path\nimport re\nimport shutil\nimport subprocess\nimport sys\nimport tempfile\nimport unittest\n\nROOT = Path(__file__).resolve().parents[1]\n\n\nclass SkillPackaging(unittest.TestCase):\n    def canonical(self):\n        found = []\n        for path in ROOT.rglob(\'SKILL.md\'):\n            if path.is_file() and re.search(r\'\'\'(?m)^name:\\s*[\'"]?proofline-check[\'"]?\\s*$\'\'\', path.read_text()):\n                found.append(path.resolve())\n        self.assertEqual(len(set(found)), 1, \'one maintained canonical definition\')\n        return found[0]\n\n    def test_metadata_and_one_maintained_definition(self):\n        self.assertTrue(self.canonical().read_text().startswith(\'---\\n\'))\n\n    def test_root_entry_and_supported_installation_documented(self):\n        self.assertTrue((ROOT / \'SKILL.md\').is_file())\n        text = (ROOT / \'README.md\').read_text().lower()\n        for term in (\'proofline-check\', \'codex\', \'claude\'):\n            self.assertIn(term, text)\n\n    def test_local_links_resolve_in_the_selected_layout(self):\n        canonical = self.canonical()\n        for match in re.finditer(r\'\\[[^\\]]+\\]\\(([^)]+)\\)\', canonical.read_text()):\n            target = match.group(1).split(\'#\', 1)[0]\n            if target and not re.match(r\'[a-z]+:\', target):\n                self.assertTrue((canonical.parent / target).exists(), target)\n        for agent in (\'.agents\', \'.claude\'):\n            entry = ROOT / agent / \'skills\' / \'proofline-check\' / \'SKILL.md\'\n            if entry.exists():\n                self.assertEqual(entry.resolve(), canonical)\n\n    def test_install_copy_retains_skill_metadata(self):\n        with tempfile.TemporaryDirectory() as temporary:\n            shutil.copytree(self.canonical().parent, Path(temporary) / \'proofline-check\')\n            copied = (Path(temporary) / \'proofline-check\' / \'SKILL.md\').read_bytes()\n            self.assertEqual(copied, self.canonical().read_bytes())\n\n    def test_python_cli_keeps_run_check_status(self):\n        result = subprocess.run([sys.executable, \'-B\', str(ROOT / \'proofline.py\'), \'--help\'],\n                                capture_output=True, text=True, timeout=15)\n        self.assertEqual(result.returncode, 0, result.stderr)\n        for command in (\'run\', \'check\', \'status\'):\n            self.assertIn(command, result.stdout)\n')
sys.argv=[sys.argv[0],sys.path[0],str(suite_file.resolve())]
import hashlib, importlib.util, io, json, os, sys, unittest
from pathlib import Path
product = Path(sys.argv[1])
sys.path.insert(0, str(product))
# Use the already-qualified native Git tools, rather than Apple's discovery shim.
git_dir = '/Library/Developer/CommandLineTools/usr/bin'
os.defpath = git_dir + ':/usr/bin:/bin'
os.environ.update(PATH=os.defpath, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
                  GIT_EXEC_PATH='/Library/Developer/CommandLineTools/usr/libexec/git-core')
spec = importlib.util.spec_from_file_location('private_regressions', sys.argv[2])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT = product
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=1).run(suite)
log = stream.getvalue().encode()
Path('regressions.log').write_bytes(log)
def bounded(items):
    return [(str(t)[:150], text[-200:]) for t,text in items[:20]]
print(json.dumps({'ran': result.testsRun, 'failures': bounded(result.failures),
                  'errors': bounded(result.errors), 'failure_count': len(result.failures),
                  'error_count': len(result.errors), 'log_sha256': hashlib.sha256(log).hexdigest(),
                  'skipped': [(str(t), why) for t,why in result.skipped],
                  'passed': result.wasSuccessful()}))
