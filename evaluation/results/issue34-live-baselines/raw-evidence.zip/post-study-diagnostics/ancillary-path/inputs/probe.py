import app,json,subprocess,sys
from pathlib import Path
completed = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],capture_output=True,text=True)
print(json.dumps({'returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr}))
