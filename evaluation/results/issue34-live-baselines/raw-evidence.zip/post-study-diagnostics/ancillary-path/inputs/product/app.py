from columns import project
def process(payload):
    return project(payload['rows'],payload.get('columns'))
