from app import process

def handle(payload):
    return process(payload)
