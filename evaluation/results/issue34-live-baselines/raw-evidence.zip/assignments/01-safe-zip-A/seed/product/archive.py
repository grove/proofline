import io, zipfile
def extract(data, destination):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        archive.extractall(destination)
        return [i.filename for i in archive.infolist() if not i.is_dir()]
