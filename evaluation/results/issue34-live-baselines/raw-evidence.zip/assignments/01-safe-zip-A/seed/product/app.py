import io, tempfile, zipfile
from pathlib import Path
import archive
def process(payload):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer,'w') as out:
        for member in payload['members']:
            out.writestr(member['name'],member.get('text',''))
    with tempfile.TemporaryDirectory() as folder:
        files = archive.extract(buffer.getvalue(),folder)
        return {'files':files,'contents':{name:(Path(folder)/name).read_text() for name in files}}
