"""Safe extraction for ZIP archives used by this repository."""

import io
import os
import re
import stat
import zipfile
from pathlib import Path


_DRIVE_PREFIX = re.compile(r"^[A-Za-z]:")


def _manifest(archive):
    """Return validated (ZipInfo, name, is_directory) entries."""
    entries = []
    paths = {}

    for info in archive.infolist():
        # ZipInfo.filename can be silently truncated at a NUL byte. Validate
        # orig_filename so malformed names cannot hide behind that behavior.
        name = getattr(info, "orig_filename", info.filename)
        if not isinstance(name, str) or not name:
            raise ValueError("empty ZIP member name")
        if "\x00" in name:
            raise ValueError("NUL in ZIP member name")
        if "\\" in name:
            raise ValueError("backslash in ZIP member name")
        if name.startswith("/"):
            raise ValueError("absolute ZIP member path")
        if _DRIVE_PREFIX.match(name):
            raise ValueError("drive-prefixed ZIP member path")

        is_directory = name.endswith("/")
        path_name = name[:-1] if is_directory else name
        parts = path_name.split("/")
        if not path_name or any(part in ("", ".", "..") for part in parts):
            raise ValueError("invalid ZIP member path component")

        mode = info.external_attr >> 16
        if stat.S_IFMT(mode) == stat.S_IFLNK:
            raise ValueError("symbolic link in ZIP archive")

        if path_name in paths:
            raise ValueError("duplicate ZIP member path")
        paths[path_name] = is_directory
        entries.append((info, path_name, is_directory))

    # A file entry cannot also be a parent directory, regardless of the
    # order in which either entry appears in the central directory.
    for _, path_name, _ in entries:
        parts = path_name.split("/")
        for end in range(1, len(parts)):
            parent = "/".join(parts[:end])
            if paths.get(parent) is False:
                raise ValueError("ZIP member file is used as a parent")

    return entries


def _reject_destination_symlinks(root, entries):
    if root.is_symlink():
        raise ValueError("destination is a symbolic link")

    # Check every path component that extraction might traverse before any
    # member is written. lexists/is_symlink also catches dangling symlinks.
    for _, path_name, _ in entries:
        current = root
        for component in path_name.split("/"):
            current = current / component
            if current.is_symlink():
                raise ValueError("destination path traverses a symbolic link")


def extract(data, destination):
    """Validate a ZIP manifest, then extract its files in archive order.

    The returned names are relative member paths for files only. Directory
    entries are created but omitted from the result.
    """
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = _manifest(archive)
        root = Path(destination)
        _reject_destination_symlinks(root, entries)

        if not entries:
            return []

        root.mkdir(parents=True, exist_ok=True)
        files = []
        for info, name, is_directory in entries:
            target = root.joinpath(*name.split("/"))
            if is_directory:
                target.mkdir(parents=True, exist_ok=True)
                continue

            target.parent.mkdir(parents=True, exist_ok=True)
            flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
            flags |= getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(target, flags, 0o666)
            with os.fdopen(descriptor, "wb") as output:
                output.write(archive.read(info))
            files.append(name)

        return files
