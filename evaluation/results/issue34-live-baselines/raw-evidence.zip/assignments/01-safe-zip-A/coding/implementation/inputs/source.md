Harden the existing ZIP extraction repository against unsafe members.
Keep archive.extract(data, destination), app.process, service.handle and CLI compatible.
Before writing any member, validate the entire ZIP manifest. Reject with ValueError:
absolute names; any backslash; NUL; drive-prefixed names; '.' or '..' path components;
empty internal components; Unix symlink members; duplicate file/directory paths
(a directory's terminal slash is ignored); a file used as another member's parent.
Reject member paths traversing any symlink within destination, and reject destination
itself if it is a symlink. Directory entries ending in '/' and an empty ZIP are valid.
On manifest rejection create no directories/files and preserve existing bytes.
After validation, extract in archive order and return only relative file names in
that order; create parent directories. Overwriting a regular existing file is allowed.
app.process accepts members=[{"name":str,"text":str,"symlink":optional bool}], uses a
temporary directory, and returns {"files":[names],"contents":{name:text}} via archive.extract.
Update service.handle to use the same validation; it must never bypass archive.extract.
For members=[{"name":"docs/"},{"name":"docs/a.txt","text":"hi"}], return
{"files":["docs/a.txt"],"contents":{"docs/a.txt":"hi"}}.
Preserve input immutability, --version and CLI error exit 2. No network or dependencies.
