import app

def handle(payload):
    """Process members through the archive extractor's manifest checks."""
    return app.process(payload)
