import io, stat, tempfile, zipfile
from pathlib import Path
import archive


def process(payload):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as out:
        for member in payload['members']:
            name = member['name']
            if not isinstance(name, str):
                raise ValueError('member name must be a string')
            # ZipInfo truncates names at NUL, so reject it before creating the
            # archive rather than letting the extractor see a different name.
            if '\x00' in name:
                raise ValueError('NUL in ZIP member name')

            if member.get('symlink', False):
                info = zipfile.ZipInfo(name)
                info.create_system = 3
                info.external_attr = (stat.S_IFLNK | 0o777) << 16
                out.writestr(info, member.get('text', ''))
            else:
                out.writestr(name, member.get('text', ''))

    with tempfile.TemporaryDirectory() as folder:
        files = archive.extract(buffer.getvalue(), folder)
        return {
            'files': files,
            'contents': {
                name: (Path(folder) / name).read_text(encoding='utf-8')
                for name in files
            },
        }
