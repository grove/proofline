import json, sys
from service import handle
if sys.argv[1:] == ['--version']:
    print('repo-v1')
elif sys.argv[1:]:
    print('ERROR: unsupported option', file=sys.stderr)
    sys.exit(2)
else:
    try:
        print(json.dumps(handle(json.load(sys.stdin)), sort_keys=True))
    except (ValueError, TypeError, KeyError) as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        sys.exit(2)
