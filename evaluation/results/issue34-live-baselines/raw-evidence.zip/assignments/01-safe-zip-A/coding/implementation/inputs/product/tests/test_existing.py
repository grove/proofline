from app import process
import unittest
class Existing(unittest.TestCase):
    def test_extract(self):
        self.assertEqual(process({'members':[{'name':'a.txt','text':'ok'}]}), {'files':['a.txt'],'contents':{'a.txt':'ok'}})
