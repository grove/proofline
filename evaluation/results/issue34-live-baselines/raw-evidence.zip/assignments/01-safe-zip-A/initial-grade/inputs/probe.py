import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/01-safe-zip-A/initial-grade/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/01-safe-zip-A/initial-grade/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/01-safe-zip-A/initial-grade/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/01-safe-zip-A/initial-grade/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
import archive
check('all seams archive order',lambda: seams({'members':[{'name':'b/c.txt','text':'c'},{'name':'a.txt','text':'a'}]},
    {'files':['b/c.txt','a.txt'],'contents':{'b/c.txt':'c','a.txt':'a'}}))
def packed(names):
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w') as out:
        for name in names: out.writestr(name.replace('\0','X'),'payload')
    result = data.getvalue()
    for name in names:
        if '\0' in name: result = result.replace(name.replace('\0','X').encode(),name.encode())
    return result
def rejection():
    with tempfile.TemporaryDirectory(dir='.') as folder:
        target=Path(folder)/'out'
        for name in ('../escape','/abs','C:drive','a\\b','a//b','a/./b','a/../b','nul\0hidden'):
            raises(ValueError,lambda: archive.extract(packed(['safe/file',name]),target))
            assert not target.exists()
        for names in (['f','f'],['d/','d/'],['d/','d'],['f/child','f']):
            raises(ValueError,lambda: archive.extract(packed(names),target))
            assert not target.exists()
        target.mkdir(); (target/'keep').write_text('old')
        (target/'link').symlink_to((target/'keep').resolve())
        raises(ValueError,lambda: archive.extract(packed(['safe/file','link']),target))
        assert (target/'keep').read_text()=='old' and not (target/'safe').exists()
        outside=Path(folder)/'outside'; outside.mkdir()
        (target/'dirlink').symlink_to(outside.resolve(),target_is_directory=True)
        raises(ValueError,lambda: archive.extract(packed(['dirlink/new']),target))
        assert list(outside.iterdir())==[]
        raises(ValueError,lambda: archive.extract(packed(['new']),target/'dirlink'))
        assert archive.extract(packed([]),target)==[]
        assert archive.extract(packed(['keep']),target)==['keep']
        assert (target/'keep').read_text()=='payload'
check('unsafe manifest, duplicates and destination symlinks',rejection)
check('symlink member',lambda: raises(ValueError,lambda: process({'members':[{'name':'shortcut','text':'elsewhere','symlink':True}]})))
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
