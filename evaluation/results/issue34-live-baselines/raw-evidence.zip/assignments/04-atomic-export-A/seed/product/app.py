from pathlib import Path
import tempfile
from exporter import write_records
def process(payload):
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/'out.jsonl'
        count = write_records(path,payload['records'])
        return {'text':path.read_text(encoding='utf-8'),'count':count}
