import json
def write_records(path, records):
    count = 0
    with open(path,'w',encoding='utf-8') as stream:
        for record in records:
            stream.write(json.dumps(record,sort_keys=True,ensure_ascii=False)+'\n')
            count += 1
    return count
