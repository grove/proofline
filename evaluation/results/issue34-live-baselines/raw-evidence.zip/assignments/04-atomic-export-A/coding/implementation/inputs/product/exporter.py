import json
import os
import tempfile
from pathlib import Path


def write_records(path, records, *, append=False):
    """Atomically write JSON Lines records to *path*.

    In append mode the previous file is copied byte for byte into the staged
    file before the new records are written. The destination is replaced only
    after the staged file has been flushed and closed.
    """
    destination = Path(path)
    existing = b""
    if append:
        try:
            existing = destination.read_bytes()
        except FileNotFoundError:
            pass

    parent = destination.parent
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", dir=parent, prefix=f".{destination.name}.", delete=False
        ) as stream:
            temporary_path = stream.name
            if append:
                stream.write(existing)
                if existing and not existing.endswith(b"\n"):
                    stream.write(b"\n")
            count = 0
            for record in records:
                if not isinstance(record, dict):
                    raise ValueError("each record must be a dictionary")
                try:
                    line = json.dumps(
                        record,
                        sort_keys=True,
                        ensure_ascii=False,
                        allow_nan=False,
                    )
                    encoded = (line + "\n").encode("utf-8")
                except (TypeError, ValueError, UnicodeError) as error:
                    raise ValueError(
                        f"record is not finite UTF-8 JSON: {error}"
                    ) from error
                stream.write(encoded)
                count += 1
            stream.flush()

        # An empty append is a true no-op, including when the destination is
        # missing. The input iterable has still been consumed and validated.
        if append and count == 0:
            return 0

        os.replace(temporary_path, destination)
        temporary_path = None
        return count
    finally:
        if temporary_path is not None:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
