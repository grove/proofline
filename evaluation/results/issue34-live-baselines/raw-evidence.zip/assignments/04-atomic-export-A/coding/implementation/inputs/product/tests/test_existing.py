from app import process
import unittest
class Existing(unittest.TestCase):
    def test_export(self):
        self.assertEqual(process({'records':[{'a':1}]}), {'text':'{"a": 1}\n','count':1})
