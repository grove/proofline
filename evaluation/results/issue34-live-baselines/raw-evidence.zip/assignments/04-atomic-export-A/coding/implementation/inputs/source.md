Make the existing JSON Lines export repository atomic and add append mode.
Keep exporter.write_records(path, records), app.process, service.handle and CLI compatible.
Add keyword-only append=False. Each record must be a dictionary serializable as
finite JSON (reject NaN/Infinity), emitted as sorted-key JSON plus one newline,
UTF-8 with ensure_ascii=False. Accept an iterable and consume it once.
Write via a temporary file in the destination directory and os.replace only after
all records are encoded and the file is flushed and closed. On invalid records,
iteration errors, write errors or replace errors, preserve the prior destination
bytes (or its absence) and remove the temporary file. Propagate the original error;
use ValueError for invalid records. Never delete the destination during cleanup.
append=True preserves existing bytes exactly, adding one separating newline only
when nonempty existing bytes lack a terminal newline. Append to a missing file works.
Return the count of new records. Empty append must leave existing bytes unchanged.
Update app.process/service.handle to use a temporary directory and payload.previous
(optional string), payload.records and payload.append; return {"text":UTF8_text,"count":n}.
For previous='old', records=[{"z":"ø"}], append=true return
{"text":"old
{"z": "ø"}
","count":1}. Preserve --version and CLI errors.
