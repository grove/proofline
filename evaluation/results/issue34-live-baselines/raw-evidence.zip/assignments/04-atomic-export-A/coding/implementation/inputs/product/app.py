from pathlib import Path
import tempfile
from exporter import write_records
def process(payload):
    previous = payload.get('previous', '')
    if not isinstance(previous, str):
        raise ValueError('previous must be a string')
    append = payload.get('append', False)
    if not isinstance(append, bool):
        raise ValueError('append must be a boolean')
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder)/'out.jsonl'
        if previous:
            path.write_text(previous, encoding='utf-8')
        count = write_records(path, payload['records'], append=append)
        return {'text':path.read_text(encoding='utf-8'),'count':count}
