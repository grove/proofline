from columns import project


def process(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if 'rows' not in payload:
        raise ValueError("rows must be a list of objects")
    if 'columns' in payload and payload['columns'] is None:
        raise ValueError("columns must be a list of distinct nonempty strings")
    return project(payload['rows'], payload.get('columns'))
