from app import process
import unittest
class Existing(unittest.TestCase):
    def test_rows(self):
        self.assertEqual(process({'rows':[{'x':1}]}), [{'x':1}])
