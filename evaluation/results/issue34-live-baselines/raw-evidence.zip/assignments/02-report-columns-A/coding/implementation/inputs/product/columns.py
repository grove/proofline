"""Helpers for projecting report rows onto a requested set of columns."""

from copy import deepcopy


def project(rows, columns=None):
    """Return independent row copies, optionally limited to ``columns``.

    Column validation deliberately happens before iterating rows so malformed
    columns are rejected even when ``rows`` is empty.
    """
    if not isinstance(rows, list):
        raise ValueError("rows must be a list of objects")

    if columns is not None:
        if not isinstance(columns, list):
            raise ValueError("columns must be a list of distinct nonempty strings")
        seen = set()
        for column in columns:
            if not isinstance(column, str) or not column or column in seen:
                raise ValueError("columns must be a list of distinct nonempty strings")
            seen.add(column)

    for row in rows:
        if not isinstance(row, dict) or any(not isinstance(key, str) for key in row):
            raise ValueError("rows must be a list of objects")

    if columns is None:
        return [deepcopy(row) for row in rows]

    return [
        {column: deepcopy(row[column]) if column in row else None for column in columns}
        for row in rows
    ]
