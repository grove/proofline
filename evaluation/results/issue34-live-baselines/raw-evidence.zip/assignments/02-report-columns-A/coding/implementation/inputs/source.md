Extend the existing report repository with optional column selection.
Keep app.process(payload), service.handle(payload), and the JSON stdin CLI compatible.
payload.rows is a list of JSON objects; absent columns returns independent deep copies
of all rows. Optional columns must be a list of distinct nonempty strings (empty
list is allowed). Return each row projected in column-list order, using null for
missing fields; preserve input row order and never mutate or alias input values.
Validate columns even when rows is empty. Invalid rows/columns raise ValueError.
For rows=[{"name":"Ada","score":7}] and columns=["score","missing"], return
[{"score":7,"missing":null}]. Existing --version output and CLI error exit 2 stay.
Factor projection into columns.project(rows, columns=None) and use it from app.
