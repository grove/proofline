def process(payload):
    return list(payload['rows'])
