import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/02-report-columns-A/initial-grade/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/02-report-columns-A/initial-grade/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/02-report-columns-A/initial-grade/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/02-report-columns-A/initial-grade/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
import columns
check('all seams, order, missing',lambda: seams({'rows':[{'b':2,'a':1},{'a':4}],'columns':['b','a']},[{'b':2,'a':1},{'b':None,'a':4}]))
check('empty selection',lambda: seams({'rows':[{'q':9}],'columns':[]},[{}]))
def aliases():
    rows = [{'nested':[{'k':3}]}]
    result = columns.project(rows)
    result[0]['nested'][0]['k']=8
    assert rows==[{'nested':[{'k':3}]}]
    result = columns.project(rows,['nested'])
    result[0]['nested'].append(5)
    assert rows==[{'nested':[{'k':3}]}]
    assert list(columns.project([{'a':1,'b':2}],['b','a'])[0])==['b','a']
check('API, order and alias freedom',aliases)
for bad in ('a',[False],[''],['r','r'],{}):
    check('invalid columns '+repr(bad),lambda bad=bad: raises(ValueError,lambda: columns.project([],bad)))
for bad in ({},[1]):
    check('invalid rows '+repr(bad),lambda bad=bad: raises(ValueError,lambda: columns.project(bad)))
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
