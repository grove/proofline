from cache import Cache
def process(payload):
    now = [0]; loads = []; values = []
    cache = Cache(lambda: now[0])
    for action in payload['actions']:
        now[0] = action.get('at',0)
        def loader():
            loads.append(1)
            return action['value']
        values.append(cache.get(action['key'],loader))
    return {'values':values,'loads':len(loads)}
