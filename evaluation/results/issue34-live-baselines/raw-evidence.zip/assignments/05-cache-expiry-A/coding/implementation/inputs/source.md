Add expiration and invalidation to the existing injected-clock cache repository.
Keep Cache(clock), Cache.get(key, loader), app.process, service.handle and CLI compatible.
Extend Cache.get(key, loader, ttl=None). None caches indefinitely; ttl is a finite
nonnegative int/float excluding bool; validate before any hit or loader call.
Use the injected clock. A finite entry expires when now >= insertion_time + ttl;
ttl=0 loads on every call. A loader exception must not populate the cache.
Return deep copies on both misses and hits so caller changes cannot corrupt entries.
Add Cache.invalidate(key) returning whether an entry existed, even if expired.
Add Cache.clear() returning the number of stored entries and removing all entries.
Wire the new options and actions through app.process and service.handle. Payload
actions are {"op":"get","key":string,"value":JSON,"at":number,"ttl":optional number},
{"op":"invalidate","key":string}, or {"op":"clear"}. Clock starts at 0 and
get actions set it to at (default 0). Return {"values":[results],"loads":count}.
For actions=[{"op":"get","key":"x","value":1,"at":0,"ttl":2},
{"op":"get","key":"x","value":2,"at":2,"ttl":2},{"op":"clear"}],
return {"values":[1,2,1],"loads":2}. Preserve --version and CLI error exit 2.
