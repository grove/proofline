from cache import Cache
def process(payload):
    now = [0]; loads = []; values = []
    cache = Cache(lambda: now[0])
    for action in payload['actions']:
        op = action.get('op', 'get')
        if op == 'get':
            now[0] = action.get('at', 0)

            def loader():
                loads.append(1)
                return action['value']

            values.append(cache.get(action['key'], loader, ttl=action.get('ttl')))
        elif op == 'invalidate':
            values.append(cache.invalidate(action['key']))
        elif op == 'clear':
            values.append(cache.clear())
        else:
            raise ValueError('unsupported action: ' + str(op))
    return {'values':values,'loads':len(loads)}
