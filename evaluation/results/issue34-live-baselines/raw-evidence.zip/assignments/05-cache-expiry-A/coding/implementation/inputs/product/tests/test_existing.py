from app import process
import unittest
class Existing(unittest.TestCase):
    def test_cache(self):
        self.assertEqual(process({'actions':[{'op':'get','key':'a','value':1}]}), {'values':[1],'loads':1})
