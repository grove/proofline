import copy
import math


class Cache:
    def __init__(self, clock):
        self.clock = clock
        # Each entry is (value, expiration_time). A None expiration means the
        # value is cached indefinitely.
        self.entries = {}

    @staticmethod
    def _validate_ttl(ttl):
        if ttl is None:
            return
        if isinstance(ttl, bool) or not isinstance(ttl, (int, float)):
            raise TypeError('ttl must be a finite nonnegative int or float')
        if ttl < 0 or (isinstance(ttl, float) and not math.isfinite(ttl)):
            raise ValueError('ttl must be a finite nonnegative int or float')

    def get(self, key, loader, ttl=None):
        # Validate on every call, including cache hits.
        self._validate_ttl(ttl)

        entry = self.entries.get(key)
        if entry is not None:
            value, expiration_time = entry
            if expiration_time is None:
                return copy.deepcopy(value)
            if self.clock() < expiration_time:
                return copy.deepcopy(value)
            del self.entries[key]

        value = loader()
        # Keep a copy separate from both the loader's object and the value
        # returned to the caller.
        stored_value = copy.deepcopy(value)
        if ttl is None:
            expiration_time = None
        else:
            insertion_time = self.clock()
            try:
                expiration_time = insertion_time + ttl
            except OverflowError:
                # A very large integer TTL can overflow when combined with a
                # floating-point clock. It still represents a valid duration.
                expiration_time = math.inf
        self.entries[key] = (stored_value, expiration_time)
        return copy.deepcopy(stored_value)

    def invalidate(self, key):
        existed = key in self.entries
        if existed:
            del self.entries[key]
        return existed

    def clear(self):
        count = len(self.entries)
        self.entries.clear()
        return count
