import client
def process(payload):
    responses = iter(payload['responses'])
    calls = []
    def transport():
        calls.append(1)
        item = next(responses)
        if item == 'timeout': raise TimeoutError('transport')
        if item == 'error': raise RuntimeError('transport')
        return item
    response = client.fetch(transport, method=payload.get('method','GET'))
    return {'response':response,'attempts':len(calls),'sleeps':[]}
