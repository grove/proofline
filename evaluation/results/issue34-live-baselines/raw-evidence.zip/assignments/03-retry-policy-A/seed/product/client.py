def fetch(transport, *, method='GET'):
    return transport()
