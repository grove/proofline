Add a bounded retry policy to the injected-transport HTTP client repository.
Implement client.fetch(transport, *, method="GET", retries=2, sleep=lambda n: None).
transport is a zero-argument callable returning {"status": integer, "body": JSON}.
Only GET and HEAD may retry status 429 or 503 and TimeoutError. All other methods
return the first response or propagate the first exception. Other exceptions
always propagate. Never change the response object or catch BaseException.
retries is the number of extra attempts, an integer >=0 excluding bool; method
must be a nonempty string, case-insensitive. Validate before transport is called.
Backoff calls sleep(1), sleep(2), ... once before each extra attempt. The final
retryable response is returned; the final TimeoutError is propagated, with no
sleep after budget exhaustion. Validate every response: dictionary, status int
excluding bool in 100..599, body key required. Invalid responses raise ValueError.
Wire app.process and service.handle to payload.method/retries/responses. For each
"timeout" or "error" response item, the fixture transport raises TimeoutError or
RuntimeError respectively. Return {"response":final_response,"attempts":n,"sleeps":[...]}.
For GET with retries=1 and responses=[{"status":503,"body":"busy"},{"status":200,"body":"ok"}],
return {"response":{"status":200,"body":"ok"},"attempts":2,"sleeps":[1]}.
Preserve the default successful request, input immutability, --version and CLI errors.
