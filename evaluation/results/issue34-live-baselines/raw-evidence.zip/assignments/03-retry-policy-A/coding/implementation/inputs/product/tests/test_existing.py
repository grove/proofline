from app import process
import unittest
class Existing(unittest.TestCase):
    def test_success(self):
        self.assertEqual(process({'responses':[{'status':200,'body':'ok'}]})['attempts'], 1)
