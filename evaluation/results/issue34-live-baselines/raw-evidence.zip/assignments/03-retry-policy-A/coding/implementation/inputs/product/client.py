def fetch(transport, *, method='GET', retries=2, sleep=lambda n: None):
    """Fetch a response, retrying transient failures for GET and HEAD requests."""
    if not isinstance(method, str) or not method:
        raise ValueError('method must be a nonempty string')
    if isinstance(retries, bool) or not isinstance(retries, int) or retries < 0:
        raise ValueError('retries must be an integer >= 0')

    retryable_method = method.upper() in ('GET', 'HEAD')
    extra_attempts = 0
    while True:
        try:
            response = transport()
        except TimeoutError:
            if not retryable_method or extra_attempts >= retries:
                raise
            extra_attempts += 1
            sleep(extra_attempts)
            continue

        if not isinstance(response, dict):
            raise ValueError('response must be a dictionary')
        status = response.get('status')
        if (isinstance(status, bool) or not isinstance(status, int)
                or not 100 <= status <= 599):
            raise ValueError('response status must be an integer from 100 to 599')
        if 'body' not in response:
            raise ValueError('response must contain a body')

        if retryable_method and status in (429, 503) and extra_attempts < retries:
            extra_attempts += 1
            sleep(extra_attempts)
            continue
        return response
