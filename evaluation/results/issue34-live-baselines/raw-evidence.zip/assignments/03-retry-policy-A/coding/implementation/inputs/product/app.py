import client
def process(payload):
    responses = iter(payload['responses'])
    calls = []
    sleeps = []
    def transport():
        calls.append(1)
        item = next(responses)
        if item == 'timeout': raise TimeoutError('transport')
        if item == 'error': raise RuntimeError('transport')
        return item
    response = client.fetch(
        transport,
        method=payload.get('method', 'GET'),
        retries=payload.get('retries', 2),
        sleep=sleeps.append,
    )
    return {'response':response,'attempts':len(calls),'sleeps':sleeps}
