import copy, io, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path
from app import process
from service import handle
results = []
def check(label, call):
    try:
        call()
        results.append({'label':label,'passed':True})
    except Exception as error:
        results.append({'label':label,'passed':False,'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert json.dumps(actual,sort_keys=True,allow_nan=False)==json.dumps(expected,sort_keys=True,allow_nan=False), (actual,expected)
def raises(kind, call):
    try: call()
    except kind: return
    raise AssertionError('expected '+kind.__name__)
def seams(payload, expected):
    original = copy.deepcopy(payload)
    eq(process(payload),expected); eq(handle(payload),expected)
    assert payload==original, 'mutated input'
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/03-retry-policy-A/initial-grade/inputs/product/cli.py'],input=json.dumps(payload),
        capture_output=True,text=True,timeout=5)
    assert command.returncode==0 and command.stderr=='', command.stderr
    eq(json.loads(command.stdout),expected)
def compatibility():
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/03-retry-policy-A/initial-grade/inputs/product/cli.py','--version'],capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/03-retry-policy-A/initial-grade/inputs/product/cli.py','--unknown'],capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout==''
    command = subprocess.run([sys.executable,'-B','/Users/grove/projects/proofline/.proofline/issue34-recovery-v1/assignments/03-retry-policy-A/initial-grade/inputs/product/cli.py'],input='{}',capture_output=True,text=True,timeout=5)
    assert command.returncode==2 and command.stdout=='' and command.stderr.startswith('ERROR:')
check('CLI compatibility',compatibility)
import client
check('HEAD timeout all seams',lambda: seams({'method':'head','retries':2,'responses':['timeout',{'status':429,'body':'wait'},{'status':201,'body':{'id':4}}]},
    {'response':{'status':201,'body':{'id':4}},'attempts':3,'sleeps':[1,2]}))
check('exhausted response',lambda: seams({'retries':1,'responses':[{'status':503,'body':0},{'status':503,'body':1}]},
    {'response':{'status':503,'body':1},'attempts':2,'sleeps':[1]}))
def failures():
    for method,kind in [('POST',TimeoutError),('GET',RuntimeError)]:
        calls=[]
        def transport():
            calls.append(1); raise kind('original')
        raises(kind,lambda: client.fetch(transport,method=method,sleep=lambda n: calls.append(n+10)))
        assert calls==[1]
    calls=[]; sleeps=[]
    def timeout():
        calls.append(1); raise TimeoutError('last')
    raises(TimeoutError,lambda: client.fetch(timeout,retries=2,sleep=sleeps.append))
    assert len(calls)==3 and sleeps==[1,2]
    raises(KeyboardInterrupt,lambda: client.fetch(lambda: (_ for _ in ()).throw(KeyboardInterrupt())))
check('exception policy and exhaustion',failures)
def invalid():
    for retries in (True,-1,1.5):
        calls=[]
        raises(ValueError,lambda: client.fetch(lambda: calls.append(1),retries=retries))
        assert calls==[]
    for method in ('',None):
        raises(ValueError,lambda: client.fetch(lambda: None,method=method))
    for response in ({'status':True,'body':0},{'status':99,'body':0},{'status':600,'body':0},{'status':200},[]):
        raises(ValueError,lambda: client.fetch(lambda: response))
    response={'status':204,'body':None}
    assert client.fetch(lambda: response) is response
check('validation and response identity',invalid)
import app
tests = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],
    capture_output=True,text=True,timeout=10)
print(json.dumps({'cases':results,'repository_tests_passed':tests.returncode==0},sort_keys=True))
