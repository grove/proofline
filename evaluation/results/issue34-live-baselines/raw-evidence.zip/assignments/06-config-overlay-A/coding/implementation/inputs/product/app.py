import settings


def process(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be a dictionary")
    if 'config' in payload and 'layers' in payload:
        raise ValueError("payload cannot contain both config and layers")
    if 'layers' in payload:
        layers = payload['layers']
    elif 'config' in payload:
        # Keep the original single-config input compatible while applying the
        # same validation, deletion, and copy rules as a one-layer merge.
        layers = [payload['config']]
    else:
        raise ValueError("payload must contain config or layers")
    return {'config': settings.merge(layers)}
