from service import handle
import unittest
class Existing(unittest.TestCase):
    def test_config(self):
        self.assertEqual(handle({'config':{'mode':'dev'}}), {'config':{'mode':'dev'}})
