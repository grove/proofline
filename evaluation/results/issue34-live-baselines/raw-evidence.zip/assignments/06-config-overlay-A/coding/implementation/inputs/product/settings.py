def _validate_value(value):
    """Reject non-string mapping keys anywhere in a configuration value."""
    if isinstance(value, dict):
        for key, nested in value.items():
            if not isinstance(key, str):
                raise ValueError("configuration dictionary keys must be strings")
            _validate_value(nested)
    elif isinstance(value, list):
        for nested in value:
            _validate_value(nested)


def _merge_dicts(current, incoming):
    """Apply one dictionary layer and return a fresh dictionary."""
    result = current.copy()
    for key, value in incoming.items():
        if value is None:
            result.pop(key, None)
        elif isinstance(value, dict):
            previous = result.get(key)
            if not isinstance(previous, dict):
                previous = {}
            result[key] = _merge_dicts(previous, value)
        elif isinstance(value, list):
            # Lists are replacement values. Deep-copy nested data so the result
            # never aliases any input layer.
            result[key] = _copy_value(value)
        else:
            result[key] = value
    return result


def _copy_value(value):
    if isinstance(value, dict):
        # Validation has already established that all keys are strings.
        return {key: _copy_value(nested) for key, nested in value.items()}
    if isinstance(value, list):
        return [_copy_value(nested) for nested in value]
    return value


def merge(layers):
    """Recursively merge configuration dictionaries from left to right.

    A null mapping value deletes that key. Lists and scalar values replace
    earlier values, and all values in the result are independent of the input.
    """
    if not isinstance(layers, list):
        raise ValueError("layers must be a list of dictionaries")

    # Validate every layer before applying any of them, including layers whose
    # values might otherwise be hidden by a later replacement.
    for layer in layers:
        if not isinstance(layer, dict):
            raise ValueError("each layer must be a dictionary")
        _validate_value(layer)

    result = {}
    for layer in layers:
        result = _merge_dicts(result, layer)
    return result
