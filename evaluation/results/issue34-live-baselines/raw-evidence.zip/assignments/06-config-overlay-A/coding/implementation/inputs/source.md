Add recursive layered configuration to the existing settings repository.
Keep app.process(payload), service.handle(payload), and the JSON stdin CLI compatible.
Implement settings.merge(layers), accepting a list of dictionaries with string keys.
Merge layers left to right: dictionaries merge recursively when both values are
dictionaries; all other values, including lists, replace the earlier value.
A null value deletes its key, including nested keys; deleting an absent key is a
no-op. Nulls inside replacement lists are data. A newly introduced dictionary
must also apply nested deletions. Do not mutate or alias any layer.
Recursively reject non-string dictionary keys, including dictionaries inside lists,
with ValueError; reject invalid layers even when earlier layers are empty.
app.process returns {"config": settings.merge(payload["layers"])}. Update
service.handle to accept the same input and return the same wrapper. The old
{"config": {...}} input remains accepted and returns a deep-copied config wrapper
via the same merge rules. Reject input containing both config and layers.
For layers=[{"db":{"host":"local","ports":[1]}},{"db":{"host":null,"ports":[2]}}],
return {"config":{"db":{"ports":[2]}}}. Preserve --version and CLI error exit 2.
