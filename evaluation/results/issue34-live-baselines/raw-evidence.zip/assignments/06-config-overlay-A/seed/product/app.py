def process(payload):
    return {'config':dict(payload['config'])}
