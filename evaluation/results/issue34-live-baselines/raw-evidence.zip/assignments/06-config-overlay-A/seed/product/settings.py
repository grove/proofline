def merge(layers):
    result = {}
    for layer in layers:
        result.update(layer)
    return result
