def handle(payload):
    return {'config':dict(payload['config'])}
