"""Publish a presentation of immutable v1 observations; no models or regrading."""
import json
import os
import shutil
import zipfile
from pathlib import Path

from checks import host_probe as host
from checks.native_checks import write_record
from evaluation.recovery import study

raw = json.loads((study.STORE / "results.json").read_text())
result = study.normalized.normalize(raw)
assert result["status"] == "EARLY_STOP_CORRECTNESS_CEILING"
assert result["model_dispatches"] == 6 and len(result["assignments"]) == 24
assert all(row["status"] == "NOT_EXECUTED" for row in result["assignments"][6:])
assert study.identities() == study.verify()["identities"]
diagnostics = json.loads((study.STORE / "post-study-diagnostics/summary.json").read_text())
assert all(row["repository_tests"] == "CHECKS PASSED" for row in diagnostics["repository_tests"])
destination = study.ROOT / "evaluation/results/issue34-live-baselines"
destination.mkdir(exist_ok=False)
rows = []
for row in result["assignments"]:
    observed = row["status"] != "NOT_EXECUTED"
    classification = ("UNOBSERVED" if not observed else
        "DISPUTED_ORACLE_EXPECTATION" if row["task"] == "cache-expiry" else "CORRECT")
    stages = [{key: stage.get(key) for key in (
        "stage", "status", "model", "reasoning_effort", "thread_id", "usage",
        "observed_session_usage", "usage_basis", "elapsed_seconds", "tool_executions")}
        for stage in row["stages"]]
    rows.append({key: row.get(key) for key in (
        "sequence", "task", "arm", "status", "initial_candidate", "final_candidate",
        "correction", "total_seconds", "grading_seconds", "probe_seconds")})
    rows[-1].update(initial_independent_correctness=classification,
        final_independent_correctness=classification,
        frozen_initial_grade=row.get("initial_grade", {}).get("correct"),
        frozen_final_grade=row.get("final_grade", {}).get("correct"),
        frozen_cases=row.get("initial_grade", {}).get("cases"), stages=stages)

arms = {}
for arm in study.report.ARMS:
    assigned = [row for row in rows if row["arm"] == arm]
    observed = [row for row in assigned if row["status"] != "NOT_EXECUTED"]
    metrics = result["metrics"]["arms"][arm]
    arms[arm] = {"assigned": 6, "executed": len(observed), "unexecuted": 6 - len(observed),
        "confirmed_correct": 5 if observed else None, "confirmed_defective": 0 if observed else None,
        "disputed_grades": 1 if observed else 0,
        "observed_success_rate": None, "rate_over_all_assigned": None,
        "rate_reason": "One oracle expectation is unsupported by the request" if observed else "No observed deliveries",
        "seconds": metrics["seconds"], "grading_seconds": metrics["grading_seconds"],
        "models": metrics["models"], "actual_billing_usd": None,
        "cost_per_independently_correct_delivery_usd": None}

write_record(destination / "results-summary.json", {
    "study_id": study.protocol()["study_id"], **study.identities(),
    "source_result_sha256": host.sha256((study.STORE / "results.json").read_bytes()),
    "status": result["status"], "interpretation": "INSUFFICIENT_ERRORS_WITH_ORACLE_VALIDITY_LIMITATION",
    "frozen_gate": result["spending_gate"],
    "gate_validity": "At most one of six baselines could be defective; threshold two cannot be reached even if the disputed grade is counted",
    "model_dispatches": 6, "assignments": rows, "arms": arms,
    "campaign_seconds": result["campaign_seconds"],
    "preparation_seconds": result["preparation_seconds"],
    "qualification_seconds": result["qualification_seconds"],
    "post_study_diagnostic_seconds": diagnostics["elapsed_seconds"],
    "recovery_observed": False, "paired_comparisons": None,
    "recommendations": {"Proofline": "INCONCLUSIVE", "selective_Sol": "INCONCLUSIVE"},
    "accounting_limits": "Billing, authoring time/tokens/cost and active human time unknown. Post-study diagnostics are separate from primary assignment budgets.",
    "presentation": "Raw frozen outcomes remain in raw-evidence.zip. Null rates mean unobserved or disputed, never 0% success. Cache was not regraded."})
shutil.copyfile(study.STORE / "approval.json", destination / "approval.json")
shutil.copyfile(study.STORE / "post-study-diagnostics/summary.json", destination / "diagnostics.json")
with zipfile.ZipFile(destination / "raw-evidence.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(study.STORE.rglob("*")):
        name = path.relative_to(study.STORE)
        if ".git" in name.parts or name.parts[0] in ("catalog-state", "qualification", "offline-controls"):
            continue
        if path.is_symlink():
            entry = zipfile.ZipInfo(str(name))
            entry.create_system = 3
            entry.external_attr = 0o120777 << 16
            archive.writestr(entry, os.readlink(path))
        elif path.is_file():
            archive.write(path, str(name))
    for name in ("issue34-post-study.py", "issue34-build-summary.py"):
        archive.write(study.ROOT / ".proofline" / name, "bookkeeping/" + name)
with zipfile.ZipFile(destination / "raw-evidence.zip") as archive:
    assert len(archive.namelist()) == len(set(archive.namelist()))
    assert host.sha256(archive.read("results.json")) == host.sha256((study.STORE / "results.json").read_bytes())
    assert not any(".git" in Path(name).parts or "catalog-state" in Path(name).parts for name in archive.namelist())
    for row in raw["assignments"][:6]:
        for stage in row["stages"]:
            name = Path(stage["receipt"]["events_path"]).relative_to(study.STORE)
            assert host.sha256(archive.read(str(name))) == stage["receipt"]["events.jsonl_sha256"]
print(json.dumps({"destination": str(destination), "diagnostic_seconds": diagnostics["elapsed_seconds"],
    "archive_bytes": (destination / "raw-evidence.zip").stat().st_size}, indent=2))
