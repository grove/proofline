"""Model-free diagnostics after the frozen campaign; never change its grades."""
import json
import time
from pathlib import Path

from checks.native_checks import write_record
from evaluation.recovery import grader, study

result = json.loads((study.STORE / "results.json").read_text())
assert result["status"] == "EARLY_STOP_CORRECTNESS_CEILING"
assert result["model_dispatches"] == 6
assert all(row["status"] == "NOT_EXECUTED" for row in result["assignments"][6:])
directory = study.STORE / "post-study-diagnostics"
directory.mkdir(exist_ok=False)
started = time.monotonic()
rows = []
for row in result["assignments"][:6]:
    candidate = Path(row["final_candidate"]["path"])
    observed = study.ordinary(candidate, study.corpus.REQUESTS[row["task"]],
        [study.checks(row["task"])[1]], directory / row["task"], 60)
    assert observed["candidate_tree"] == row["final_candidate"]["tree"]
    rows.append({"sequence": row["sequence"], "task": row["task"],
        "candidate_tree": observed["candidate_tree"],
        "repository_tests": observed["status"],
        "elapsed_seconds": observed["elapsed_seconds"]})

# Expose the child output the frozen ancillary test flag discarded, on one
# prevalidated reference control. This is a path diagnosis, not a new oracle.
reference = study.STORE / "qualification/controls/report-columns/reference/seed/product"
script = """import app,json,subprocess,sys
from pathlib import Path
completed = subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(Path(app.__file__).parent/'tests')],capture_output=True,text=True)
print(json.dumps({'returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr}))
"""
ancillary = grader.invoke(reference, script, directory / "ancillary-path", seconds=30)
assert ancillary["available"]
child = json.loads(ancillary["receipt"]["stdout"])
assert child["returncode"] != 0 and "ModuleNotFoundError" in child["stderr"]

request = study.corpus.REQUESTS["cache-expiry"]
assert "ValueError" not in request and "TypeError" not in request
cache = result["assignments"][4]
failed = [case for case in cache["initial_grade"]["cases"] if not case["passed"]]
assert len(failed) == 1 and failed[0]["error"].startswith("TypeError:")
write_record(directory / "summary.json", {
    "scope": "Post-campaign diagnostics only; no grading, feedback, repair or model dispatch",
    "model_dispatches": 0, "repository_tests": rows,
    "ancillary_test_flag": {"trustworthy": False, "reference_child": child,
        "reason": "Child unittest discovery runs from scratch without product on sys.path"},
    "cache_oracle": {"trustworthy_failure": False, "frozen_failed_case": failed[0],
        "reason": "Frozen request requires TTL validation but does not specify its exception class",
        "independent_correctness": "UNRESOLVED_ORACLE_EXPECTATION",
        "no_regrading": True},
    "elapsed_seconds": time.monotonic() - started})
print(json.dumps(rows, indent=2))
