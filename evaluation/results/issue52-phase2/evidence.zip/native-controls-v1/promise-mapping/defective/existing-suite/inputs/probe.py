import os, subprocess, sys, json
os.environ.update(PATH='/Library/Developer/CommandLineTools/usr/bin:/usr/bin:/bin', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_EXEC_PATH='/Library/Developer/CommandLineTools/usr/libexec/git-core')
product=sys.path[0]
argv=['/opt/homebrew/Cellar/python@3.14/3.14.8_2/Frameworks/Python.framework/Versions/3.14/bin/python3.14', "-B", "-m", "unittest", "discover", "-s", "tests"]
p=subprocess.run(argv,cwd=product,capture_output=True,text=True,timeout=150)
print(json.dumps(dict(argv=argv,cwd=product,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)))
