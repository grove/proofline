import os; os.defpath='/Library/Developer/CommandLineTools/usr/bin:/usr/bin:/bin'
