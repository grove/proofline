from collections.abc import Mapping


def _is_integer(value):
    """Return whether value is an integer, excluding Python's bool subtype."""
    return isinstance(value, int) and not isinstance(value, bool)


def process(payload):
    """Apply an idempotent sequence of balance events without mutating input."""
    if not isinstance(payload, Mapping):
        raise ValueError("payload must be an object")
    if "balances" not in payload or "events" not in payload:
        raise ValueError("payload must contain balances and events")

    initial_balances = payload["balances"]
    events = payload["events"]
    if not isinstance(initial_balances, Mapping):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    # Work on a new dictionary so neither success nor failure can modify input.
    balances = dict(initial_balances)
    for account, balance in balances.items():
        if not isinstance(account, str) or not account:
            raise ValueError("balance account names must be nonempty strings")
        if not _is_integer(balance) or balance < 0:
            raise ValueError("balances must be nonnegative integers")

    applied = []
    replayed = []
    seen = {}

    for event in events:
        if not isinstance(event, Mapping):
            raise ValueError("each event must be an object")
        if not all(key in event for key in ("id", "account", "delta")):
            raise ValueError("each event must contain id, account and delta")

        event_id = event["id"]
        account = event["account"]
        delta = event["delta"]
        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event ids must be nonempty strings")
        if not isinstance(account, str) or not account:
            raise ValueError("event account names must be nonempty strings")
        if not _is_integer(delta):
            raise ValueError("event deltas must be integers")
        if account not in balances:
            raise ValueError("event account does not exist")

        identity = (account, delta)
        if event_id in seen:
            if seen[event_id] != identity:
                raise ValueError("conflicting replay for event id")
            replayed.append(event_id)
            continue

        new_balance = balances[account] + delta
        if new_balance < 0:
            raise ValueError("event would make balance negative")
        balances[account] = new_balance
        seen[event_id] = identity
        applied.append(event_id)

    return {"balances": balances, "applied": applied, "replayed": replayed}
