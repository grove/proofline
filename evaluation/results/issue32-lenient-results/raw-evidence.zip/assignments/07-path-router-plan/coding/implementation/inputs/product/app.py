import re
from urllib.parse import unquote_to_bytes


_BAD_PERCENT_ESCAPE = re.compile(r"%(?![0-9a-fA-F]{2})")


def _segments(value, *, decode):
    """Validate a slash-delimited value and return its segments."""
    if not isinstance(value, str):
        raise ValueError("patterns and paths must be strings")
    if not value.startswith("/"):
        raise ValueError("patterns and paths must begin with /")
    if value == "/":
        return []

    segments = value[1:].split("/")
    if any(segment == "" for segment in segments):
        raise ValueError("empty path and pattern segments are invalid")

    if not decode:
        return segments

    decoded = []
    for segment in segments:
        if _BAD_PERCENT_ESCAPE.search(segment):
            raise ValueError("malformed percent escape")
        try:
            decoded.append(unquote_to_bytes(segment).decode("utf-8", errors="strict"))
        except UnicodeDecodeError as error:
            raise ValueError("path segment is not valid UTF-8") from error
    return decoded


def _parse_pattern(pattern):
    segments = _segments(pattern, decode=False)
    parsed = []
    names = set()
    literal_count = 0
    has_wildcard = False

    for index, segment in enumerate(segments):
        if segment.startswith(":") or segment.startswith("*"):
            kind = segment[0]
            name = segment[1:]
            if not name:
                raise ValueError("capture names must be nonempty")
            if name in names:
                raise ValueError("capture names must be unique within a pattern")
            names.add(name)
            if kind == "*":
                if index != len(segments) - 1:
                    raise ValueError("wildcard captures must be last")
                has_wildcard = True
            parsed.append((kind, name))
        else:
            literal_count += 1
            parsed.append(("literal", segment))

    return parsed, literal_count, has_wildcard


def _validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "routes" not in payload or not isinstance(payload["routes"], list):
        raise ValueError("routes must be a list")
    if "paths" not in payload or not isinstance(payload["paths"], list):
        raise ValueError("paths must be a list")

    routes = []
    for index, route in enumerate(payload["routes"]):
        if not isinstance(route, dict):
            raise ValueError("each route must be an object")
        pattern = route.get("pattern")
        name = route.get("name")
        if not isinstance(pattern, str):
            raise ValueError("route pattern must be a string")
        if not isinstance(name, str) or not name:
            raise ValueError("route name must be a nonempty string")
        parsed, literal_count, has_wildcard = _parse_pattern(pattern)
        routes.append((name, parsed, literal_count, has_wildcard, len(parsed), index))

    paths = [_segments(path, decode=True) for path in payload["paths"]]
    return routes, paths


def _match(route, path):
    name, pattern, _, has_wildcard, _, _ = route
    if has_wildcard:
        fixed_count = len(pattern) - 1
        if len(path) < fixed_count:
            return None
    elif len(path) != len(pattern):
        return None

    params = {}
    for index, (kind, value) in enumerate(pattern):
        if kind == "literal":
            if path[index] != value:
                return None
        elif kind == ":":
            params[value] = path[index]
        else:
            params[value] = path[index:]
    return {"name": name, "params": params}


def process(payload):
    routes, paths = _validate(payload)
    matches = []
    for path in paths:
        winner = None
        winner_rank = None
        for route in routes:
            result = _match(route, path)
            if result is None:
                continue
            _, _, literal_count, has_wildcard, segment_count, original_index = route
            rank = (literal_count, not has_wildcard, segment_count, -original_index)
            if winner_rank is None or rank > winner_rank:
                winner = result
                winner_rank = rank
        matches.append(winner)
    return {"matches": matches}
