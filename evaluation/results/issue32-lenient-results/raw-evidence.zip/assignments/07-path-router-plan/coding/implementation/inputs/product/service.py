import app


def handle(payload):
    return app.process(payload)


def batch(payloads):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")

    results = []
    for payload in payloads:
        try:
            results.append(app.process(payload))
        except (TypeError, ValueError) as error:
            raise ValueError("each payload must be valid") from error
    return results
