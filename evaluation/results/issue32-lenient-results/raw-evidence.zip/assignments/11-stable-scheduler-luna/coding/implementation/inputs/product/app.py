import heapq


def _validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    workers = payload.get("workers")
    if isinstance(workers, bool) or not isinstance(workers, int) or workers <= 0:
        raise ValueError("workers must be a positive integer")

    tasks = payload.get("tasks")
    if not isinstance(tasks, list):
        raise ValueError("tasks must be a list")

    ids = []
    durations = []
    requirements = []
    index_by_id = {}

    for position, task in enumerate(tasks):
        if not isinstance(task, dict):
            raise ValueError("each task must be an object")

        task_id = task.get("id")
        if not isinstance(task_id, str) or not task_id:
            raise ValueError("task IDs must be nonempty strings")
        if task_id in index_by_id:
            raise ValueError("task IDs must be unique")

        duration = task.get("duration")
        if isinstance(duration, bool) or not isinstance(duration, int) or duration < 0:
            raise ValueError("task durations must be nonnegative integers")

        requires = task.get("requires")
        if not isinstance(requires, list):
            raise ValueError("task requirements must be a list")
        for dependency in requires:
            if not isinstance(dependency, str):
                raise ValueError("dependency IDs must be strings")
            if dependency == task_id:
                raise ValueError("tasks cannot depend on themselves")

        index_by_id[task_id] = position
        ids.append(task_id)
        durations.append(duration)
        requirements.append(requires)

    dependencies = [[] for _ in tasks]
    dependents = [[] for _ in tasks]
    for position, requires in enumerate(requirements):
        seen = set()
        for dependency in requires:
            if dependency not in index_by_id:
                raise ValueError("dependency does not exist")
            dependency_index = index_by_id[dependency]
            if dependency_index in seen:
                continue
            seen.add(dependency_index)
            dependencies[position].append(dependency_index)
            dependents[dependency_index].append(position)

    # Check the entire graph before scheduling, including components that
    # would otherwise remain undispatched after another task gets stuck.
    remaining_dependencies = [len(items) for items in dependencies]
    ready = [i for i, count in enumerate(remaining_dependencies) if count == 0]
    cursor = 0
    visited = 0
    while cursor < len(ready):
        finished = ready[cursor]
        cursor += 1
        visited += 1
        for dependent in dependents[finished]:
            remaining_dependencies[dependent] -= 1
            if remaining_dependencies[dependent] == 0:
                ready.append(dependent)
    if visited != len(tasks):
        raise ValueError("task dependencies contain a cycle")

    return workers, ids, durations, dependencies, dependents


def process(payload):
    workers, ids, durations, dependencies, dependents = _validate(payload)
    task_count = len(ids)
    if task_count == 0:
        return {"schedule": []}

    unmet = [len(items) for items in dependencies]
    ready_tasks = [index for index, count in enumerate(unmet) if count == 0]
    heapq.heapify(ready_tasks)
    # Workers above the task count can never be used, and need not be stored.
    idle_workers = list(range(min(workers, task_count)))
    heapq.heapify(idle_workers)
    running = []  # (finish time, worker, task index)
    schedule = []
    now = 0

    while len(schedule) < task_count:
        # All work finishing now becomes complete before any task is chosen.
        while running and running[0][0] <= now:
            finish, worker, finished_task = heapq.heappop(running)
            heapq.heappush(idle_workers, worker)
            for dependent in dependents[finished_task]:
                unmet[dependent] -= 1
                if unmet[dependent] == 0:
                    heapq.heappush(ready_tasks, dependent)

        # The min-heap preserves original input order among ready tasks, and
        # newly ready dependents of zero-duration tasks join before selection.
        while idle_workers and ready_tasks:
            next_task = heapq.heappop(ready_tasks)
            worker = heapq.heappop(idle_workers)
            finish = now + durations[next_task]
            schedule.append({
                "id": ids[next_task],
                "start": now,
                "finish": finish,
                "worker": worker,
            })

            if durations[next_task] == 0:
                for dependent in dependents[next_task]:
                    unmet[dependent] -= 1
                    if unmet[dependent] == 0:
                        heapq.heappush(ready_tasks, dependent)
                heapq.heappush(idle_workers, worker)
            else:
                heapq.heappush(running, (finish, worker, next_task))

        if len(schedule) == task_count:
            break
        if running:
            now = running[0][0]
        else:
            # The graph was validated as acyclic, so this indicates an
            # internal scheduler inconsistency rather than invalid input.
            raise ValueError("unable to schedule tasks")

    return {"schedule": schedule}
