def process(payload):
    """Apply ledger events once per ID without modifying the input."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    balances = payload.get("balances")
    events = payload.get("events")
    if not isinstance(balances, dict):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    for account, balance in balances.items():
        if not isinstance(account, str) or not account:
            raise ValueError("balance accounts must be nonempty strings")
        if not isinstance(balance, int) or isinstance(balance, bool) or balance < 0:
            raise ValueError("balances must be nonnegative integers")

    final_balances = balances.copy()
    seen = {}
    applied = []
    replayed = []
    for event in events:
        if not isinstance(event, dict):
            raise ValueError("events must be objects")
        event_id = event.get("id")
        account = event.get("account")
        delta = event.get("delta")
        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event IDs must be nonempty strings")
        if not isinstance(account, str) or not account:
            raise ValueError("event accounts must be nonempty strings")
        if account not in final_balances:
            raise ValueError("event account must already exist")
        if not isinstance(delta, int) or isinstance(delta, bool):
            raise ValueError("event deltas must be integers")

        identity = (account, delta)
        if event_id in seen:
            if seen[event_id] != identity:
                raise ValueError("conflicting replay for event ID: " + event_id)
            replayed.append(event_id)
            continue

        balance = final_balances[account] + delta
        if balance < 0:
            raise ValueError("event would make a balance negative")
        final_balances[account] = balance
        seen[event_id] = identity
        applied.append(event_id)

    return {"balances": final_balances, "applied": applied, "replayed": replayed}
