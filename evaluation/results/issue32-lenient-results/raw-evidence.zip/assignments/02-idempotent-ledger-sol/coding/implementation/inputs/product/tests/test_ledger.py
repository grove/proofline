import copy
import json
import pathlib
import subprocess
import sys
import unittest

from app import process
import service


class Ledger(unittest.TestCase):
    def test_replays_ignore_extra_keys_and_preserve_occurrence_order(self):
        payload = {
            "balances": {"a": 2, "b": 0},
            "events": [
                {"id": "x", "account": "a", "delta": -2, "note": "first"},
                {"id": "y", "account": "b", "delta": 3},
                {"id": "x", "account": "a", "delta": -2, "note": "changed"},
                {"id": "x", "account": "a", "delta": -2},
                {"id": "y", "account": "b", "delta": 3},
                {"id": "z", "account": "a", "delta": 0},
            ],
            "metadata": {"allowed": True},
        }
        original = copy.deepcopy(payload)
        expected = {
            "balances": {"a": 0, "b": 3},
            "applied": ["x", "y", "z"],
            "replayed": ["x", "x", "y"],
        }
        self.assertEqual(process(payload), expected)
        self.assertEqual(service.handle(payload), expected)
        self.assertEqual(payload, original)

    def test_empty_ledgers_and_independent_output(self):
        self.assertEqual(process({"balances": {}, "events": []}),
                         {"balances": {}, "applied": [], "replayed": []})
        payload = {"balances": {"a": 0}, "events": []}
        result = process(payload)
        result["balances"]["a"] = 10
        self.assertEqual(payload["balances"], {"a": 0})

    def test_events_are_applied_in_order(self):
        payload = {"balances": {"a": 0}, "events": [
            {"id": "credit", "account": "a", "delta": 2},
            {"id": "debit", "account": "a", "delta": -2},
        ]}
        self.assertEqual(process(payload)["balances"], {"a": 0})
        payload["events"].reverse()
        original = copy.deepcopy(payload)
        with self.assertRaises(ValueError):
            process(payload)
        self.assertEqual(payload, original)

    def test_invalid_payloads(self):
        invalid = [
            None, [], 1, {}, {"balances": {}}, {"events": []},
            {"balances": [], "events": []},
            {"balances": {}, "events": {}},
            {"balances": {}, "events": ()},
        ]
        for account in ["", 1, None]:
            invalid.append({"balances": {account: 0}, "events": []})
        for balance in [-1, True, False, 1.0, "1", None]:
            invalid.append({"balances": {"a": balance}, "events": []})
        for payload in invalid:
            with self.subTest(payload=payload):
                original = copy.deepcopy(payload)
                with self.assertRaises(ValueError):
                    process(payload)
                self.assertEqual(payload, original)

    def test_invalid_events_and_replays_never_mutate_input(self):
        # Each failure follows a valid applied event, exercising late rejection.
        first = {"id": "x", "account": "a", "delta": 1}
        invalid = [None, [], {},
                   {"id": "x", "account": "b", "delta": 1},
                   {"id": "x", "account": "a", "delta": 2},
                   {"id": "y", "account": "a", "delta": -4}]
        for field, values in {
            "id": [None, "", True, [], 1],
            "account": [None, "", True, [], "missing"],
            "delta": [None, True, False, 1.0, "1", []],
        }.items():
            missing = first.copy()
            del missing[field]
            invalid.append(missing)
            for value in values:
                event = first.copy()
                event[field] = value
                invalid.append(event)
        for event in invalid:
            with self.subTest(event=event):
                payload = {"balances": {"a": 2, "b": 0},
                           "events": [first.copy(), event]}
                original = copy.deepcopy(payload)
                with self.assertRaises(ValueError):
                    process(payload)
                self.assertEqual(payload, original)

    def test_batch_order_and_input_preservation(self):
        payload = {"balances": {"a": 2}, "events": [
            {"id": "x", "account": "a", "delta": -1},
            {"id": "x", "account": "a", "delta": -1},
        ]}
        payloads = [payload, {"balances": {}, "events": []}, payload]
        original = copy.deepcopy(payloads)
        results = service.batch(payloads)
        self.assertEqual(results, [process(item) for item in payloads])
        self.assertEqual(payloads, original)
        results[0]["balances"]["a"] = 99
        self.assertEqual(results[2]["balances"], {"a": 1})
        self.assertEqual(payloads, original)
        self.assertEqual(service.batch([]), [])
        for invalid in [None, {}, (), "", [payload, None],
                        [payload, {"balances": {"a": 0}, "events": [
                            {"id": "x", "account": "a", "delta": -1}]}]]:
            with self.subTest(invalid=invalid):
                original = copy.deepcopy(invalid)
                with self.assertRaises(ValueError):
                    service.batch(invalid)
                self.assertEqual(invalid, original)


class Cli(unittest.TestCase):
    def run_cli(self, payload, *args):
        repo = pathlib.Path(__file__).resolve().parents[1]
        return subprocess.run([sys.executable, "-B", str(repo / "cli.py"), *args],
                              input=json.dumps(payload), cwd=repo,
                              capture_output=True, text=True, timeout=5)

    def test_json_processing_and_errors(self):
        payload = {"balances": {"a": 2}, "events": [
            {"id": "x", "account": "a", "delta": -1},
            {"id": "x", "account": "a", "delta": -1},
        ]}
        result = self.run_cli(payload)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")
        self.assertEqual(json.loads(result.stdout), process(payload))
        result = self.run_cli({"balances": {"a": True}, "events": []})
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertTrue(result.stderr.startswith("ERROR: "))

    def test_unsupported_arguments(self):
        for args in [("--unknown",), ("--version", "extra")]:
            with self.subTest(args=args):
                result = self.run_cli(None, *args)
                self.assertEqual((result.returncode, result.stdout, result.stderr),
                                 (2, "", "ERROR: unsupported arguments\n"))
