import re
from urllib.parse import unquote_to_bytes


_BAD_ESCAPE = re.compile(r"%(?![0-9A-Fa-f]{2})")


def _split_path(value, field):
    """Validate the path shape and return its raw (not yet decoded) segments."""
    if not isinstance(value, str):
        raise ValueError("{} must be a string".format(field))
    if not value.startswith("/"):
        raise ValueError("{} must begin with /".format(field))
    if value == "/":
        return []
    segments = value[1:].split("/")
    if any(segment == "" for segment in segments):
        raise ValueError("{} must not contain empty segments".format(field))
    return segments


def _decode_segment(segment):
    if _BAD_ESCAPE.search(segment):
        raise ValueError("path contains a malformed percent escape")
    try:
        return unquote_to_bytes(segment).decode("utf-8", errors="strict")
    except UnicodeError as error:
        raise ValueError("path contains invalid UTF-8") from error


def _compile_route(route, index):
    if not isinstance(route, dict):
        raise ValueError("each route must be an object")
    if "pattern" not in route or "name" not in route:
        raise ValueError("each route must have pattern and name")
    name = route["name"]
    if not isinstance(name, str) or name == "":
        raise ValueError("route name must be a nonempty string")

    raw_segments = _split_path(route["pattern"], "route pattern")
    segments = []
    capture_names = set()
    literal_count = 0
    wildcard = False
    for position, raw_segment in enumerate(raw_segments):
        if raw_segment.startswith(":") or raw_segment.startswith("*"):
            capture_name = raw_segment[1:]
            if capture_name == "":
                raise ValueError("route capture names must be nonempty")
            if capture_name in capture_names:
                raise ValueError("route capture names must be unique")
            capture_names.add(capture_name)
            if raw_segment[0] == "*":
                if position != len(raw_segments) - 1:
                    raise ValueError("wildcard capture must be the last segment")
                wildcard = True
                segments.append(("wildcard", capture_name))
            else:
                segments.append(("capture", capture_name))
        else:
            literal_count += 1
            segments.append(("literal", raw_segment))

    return {
        "name": name,
        "segments": segments,
        "literal_count": literal_count,
        "wildcard": wildcard,
        "index": index,
    }


def _match(route, path_segments):
    pattern_segments = route["segments"]
    has_wildcard = route["wildcard"]
    fixed_count = len(pattern_segments) - (1 if has_wildcard else 0)
    if (len(path_segments) < fixed_count or
            (not has_wildcard and len(path_segments) != fixed_count)):
        return None

    params = {}
    for position, (kind, value) in enumerate(pattern_segments[:fixed_count]):
        path_segment = path_segments[position]
        if kind == "literal":
            if value != path_segment:
                return None
        else:
            params[value] = path_segment

    if has_wildcard:
        wildcard_name = pattern_segments[-1][1]
        params[wildcard_name] = path_segments[fixed_count:]
    return params


def process(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "routes" not in payload or "paths" not in payload:
        raise ValueError("payload must have routes and paths")
    routes = payload["routes"]
    paths = payload["paths"]
    if not isinstance(routes, list):
        raise ValueError("routes must be a list")
    if not isinstance(paths, list):
        raise ValueError("paths must be a list")

    # Compile every route before matching paths so even unused invalid routes
    # are rejected.
    compiled_routes = [_compile_route(route, index)
                       for index, route in enumerate(routes)]
    decoded_paths = []
    for path in paths:
        raw_segments = _split_path(path, "path")
        decoded_paths.append([_decode_segment(segment)
                              for segment in raw_segments])

    matches = []
    for path_segments in decoded_paths:
        best_route = None
        best_params = None
        best_score = None
        for route in compiled_routes:
            params = _match(route, path_segments)
            if params is None:
                continue
            score = (route["literal_count"], not route["wildcard"],
                     len(route["segments"]), -route["index"])
            if best_score is None or score > best_score:
                best_route, best_params, best_score = route, params, score
        if best_route is None:
            matches.append(None)
        else:
            matches.append({"name": best_route["name"],
                            "params": best_params})
    return {"matches": matches}
