import re
from urllib.parse import unquote_to_bytes


_BAD_ESCAPE = re.compile(r"%(?![0-9a-fA-F]{2})")


def _segments(value, label):
    """Split a route or path after checking its slash structure."""
    if not isinstance(value, str):
        raise ValueError(f"{label} must be a string")
    if not value.startswith("/"):
        raise ValueError(f"{label} must begin with /")
    if value == "/":
        return []
    pieces = value[1:].split("/")
    if any(piece == "" for piece in pieces):
        raise ValueError(f"{label} contains an empty segment")
    return pieces


def _parse_pattern(pattern):
    pieces = _segments(pattern, "pattern")
    parsed = []
    names = set()
    for index, piece in enumerate(pieces):
        if piece.startswith(":") or piece.startswith("*"):
            kind = "capture" if piece[0] == ":" else "wildcard"
            name = piece[1:]
            if not name:
                raise ValueError("capture names must be nonempty")
            if name in names:
                raise ValueError("capture names must be unique within a pattern")
            names.add(name)
            if kind == "wildcard" and index != len(pieces) - 1:
                raise ValueError("wildcard must be the last pattern segment")
            parsed.append((kind, name))
        else:
            parsed.append(("literal", piece))
    return parsed


def _decode_path(path):
    encoded_segments = _segments(path, "path")
    decoded = []
    for segment in encoded_segments:
        if _BAD_ESCAPE.search(segment):
            raise ValueError("path contains a malformed percent escape")
        try:
            decoded.append(unquote_to_bytes(segment).decode("utf-8", errors="strict"))
        except (UnicodeDecodeError, UnicodeEncodeError) as error:
            raise ValueError("path contains invalid UTF-8") from error
    return decoded


def _validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "routes" not in payload or "paths" not in payload:
        raise ValueError("payload must contain routes and paths")
    routes = payload["routes"]
    paths = payload["paths"]
    if not isinstance(routes, list):
        raise ValueError("routes must be a list")
    if not isinstance(paths, list):
        raise ValueError("paths must be a list")

    compiled = []
    for route in routes:
        if not isinstance(route, dict):
            raise ValueError("each route must be an object")
        if "pattern" not in route or "name" not in route:
            raise ValueError("each route must contain pattern and name")
        name = route["name"]
        if not isinstance(name, str) or not name:
            raise ValueError("route name must be a nonempty string")
        segments = _parse_pattern(route["pattern"])
        literal_count = sum(kind == "literal" for kind, _ in segments)
        has_wildcard = any(kind == "wildcard" for kind, _ in segments)
        compiled.append((segments, name, literal_count, has_wildcard))

    decoded_paths = [_decode_path(path) for path in paths]
    return compiled, decoded_paths


def _match(pattern, path):
    wildcard = bool(pattern and pattern[-1][0] == "wildcard")
    fixed_count = len(pattern) - int(wildcard)
    if (not wildcard and len(path) != len(pattern)) or len(path) < fixed_count:
        return None

    params = {}
    for index, (kind, value) in enumerate(pattern[:fixed_count]):
        segment = path[index]
        if kind == "literal":
            if segment != value:
                return None
        elif kind == "capture":
            params[value] = segment
    if wildcard:
        params[pattern[-1][1]] = path[fixed_count:]
    return params


def process(payload):
    """Match each path against the best route and return its captures."""
    routes, paths = _validate(payload)
    results = []
    for path in paths:
        best = None
        best_score = None
        for route_index, (pattern, name, literal_count, has_wildcard) in enumerate(routes):
            params = _match(pattern, path)
            if params is None:
                continue
            score = (literal_count, not has_wildcard, len(pattern), -route_index)
            if best_score is None or score > best_score:
                best = {"name": name, "params": params}
                best_score = score
        results.append(best)
    return {"matches": results}
