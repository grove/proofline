def process(payload):
    """Apply a sequence of idempotent ledger events without mutating input."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    balances = payload.get("balances")
    events = payload.get("events")
    if not isinstance(balances, dict):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    # Validate and copy the complete starting balance map before applying any
    # events. A private working copy also makes rejection atomic for callers.
    final_balances = {}
    for account, balance in balances.items():
        if not isinstance(account, str) or not account:
            raise ValueError("account names must be nonempty strings")
        if not isinstance(balance, int) or isinstance(balance, bool) or balance < 0:
            raise ValueError("balances must be nonnegative integers")
        final_balances[account] = balance

    seen = {}
    applied = []
    replayed = []
    for event in events:
        if not isinstance(event, dict):
            raise ValueError("each event must be an object")
        event_id = event.get("id")
        account = event.get("account")
        delta = event.get("delta")
        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event id must be a nonempty string")
        if not isinstance(account, str) or not account:
            raise ValueError("event account must be a nonempty string")
        if not isinstance(delta, int) or isinstance(delta, bool):
            raise ValueError("event delta must be an integer")
        if account not in final_balances:
            raise ValueError("event account does not exist")

        identity = (account, delta)
        if event_id in seen:
            if seen[event_id] != identity:
                raise ValueError("conflicting replay for event id")
            replayed.append(event_id)
            continue

        new_balance = final_balances[account] + delta
        if new_balance < 0:
            raise ValueError("event would make balance negative")
        final_balances[account] = new_balance
        seen[event_id] = identity
        applied.append(event_id)

    return {"balances": final_balances, "applied": applied, "replayed": replayed}
