import app


def handle(payload):
    return app.process(payload)


def batch(payloads):
    """Process payloads independently and return results in input order."""
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")

    results = []
    for payload in payloads:
        try:
            results.append(app.process(payload))
        except (ValueError, TypeError) as error:
            # Batch has a single rejection contract regardless of which
            # validation detail failed in an individual payload.
            raise ValueError(str(error)) from error
    return results
