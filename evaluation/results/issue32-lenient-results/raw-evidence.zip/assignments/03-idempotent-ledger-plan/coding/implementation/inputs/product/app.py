def _is_integer(value):
    """Return whether value is an integer, excluding Python's bool subtype."""
    return isinstance(value, int) and not isinstance(value, bool)


def process(payload):
    """Apply an ordered, idempotent set of ledger events without mutating input."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "balances" not in payload or "events" not in payload:
        raise ValueError("payload must contain balances and events")

    balances = payload["balances"]
    events = payload["events"]
    if not isinstance(balances, dict):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    # Work exclusively on fresh containers so failures cannot leave partial
    # changes in the caller's payload.
    final_balances = {}
    for account, balance in balances.items():
        if not isinstance(account, str) or not account:
            raise ValueError("account names must be nonempty strings")
        if not _is_integer(balance) or balance < 0:
            raise ValueError("balances must be nonnegative integers")
        final_balances[account] = balance

    seen = {}
    applied = []
    replayed = []

    for event in events:
        if not isinstance(event, dict):
            raise ValueError("each event must be an object")
        if not all(field in event for field in ("id", "account", "delta")):
            raise ValueError("each event must contain id, account, and delta")

        event_id = event["id"]
        account = event["account"]
        delta = event["delta"]
        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event id must be a nonempty string")
        if not isinstance(account, str) or not account:
            raise ValueError("event account must be a nonempty string")
        if not _is_integer(delta):
            raise ValueError("event delta must be an integer")
        if account not in final_balances:
            raise ValueError("event account does not exist")

        details = (account, delta)
        if event_id in seen:
            if seen[event_id] != details:
                raise ValueError("conflicting replay for event id")
            replayed.append(event_id)
            continue

        new_balance = final_balances[account] + delta
        if new_balance < 0:
            raise ValueError("event would make balance negative")
        final_balances[account] = new_balance
        seen[event_id] = details
        applied.append(event_id)

    return {
        "balances": final_balances,
        "applied": applied,
        "replayed": replayed,
    }
