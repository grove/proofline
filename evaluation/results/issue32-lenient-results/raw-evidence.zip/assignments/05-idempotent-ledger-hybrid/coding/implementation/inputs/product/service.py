import app


def handle(payload):
    return app.process(payload)


def batch(payloads):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    # Results remain local until every member has succeeded; process itself
    # does not mutate inputs, so a failing member cannot leave partial changes.
    return [app.process(payload) for payload in payloads]
