def process(payload):
    """Apply an ordered, idempotent set of ledger events to a payload."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")

    balances = payload.get("balances")
    events = payload.get("events")
    if not isinstance(balances, dict):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    # Work on a fresh mapping so neither successful processing nor a later
    # validation/application error can alter the caller's input.
    final_balances = {}
    for account, balance in balances.items():
        if isinstance(balance, bool) or not isinstance(balance, int) or balance < 0:
            raise ValueError("balances must be nonnegative integers")
        final_balances[account] = balance

    seen = {}
    applied = []
    replayed = []

    for event in events:
        if not isinstance(event, dict):
            raise ValueError("each event must be an object")
        event_id = event.get("id")
        account = event.get("account")
        delta = event.get("delta")

        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event id must be a nonempty string")
        if not isinstance(account, str) or not account:
            raise ValueError("event account must be a nonempty string")
        if isinstance(delta, bool) or not isinstance(delta, int):
            raise ValueError("event delta must be an integer")
        if account not in final_balances:
            raise ValueError("event account must already exist")

        identity = (account, delta)
        if event_id in seen:
            if seen[event_id] != identity:
                raise ValueError("conflicting event replay")
            replayed.append(event_id)
            continue

        updated = final_balances[account] + delta
        if updated < 0:
            raise ValueError("event would make balance negative")
        final_balances[account] = updated
        seen[event_id] = identity
        applied.append(event_id)

    return {"balances": final_balances, "applied": applied, "replayed": replayed}
