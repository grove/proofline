import copy
import hashlib
import json
import pathlib
import signal
import subprocess
import sys

signal.alarm(25)
inputs = pathlib.Path.cwd().parent / 'inputs'
product = inputs / 'product'
sys.path.insert(0, str(product))
import app
import service

checks = json.loads((inputs / 'checks.json').read_text())
evidence = json.loads((inputs / 'check-evidence.json').read_text())
assert evidence['checks'] == checks
assert hashlib.sha256((inputs / 'source.md').read_bytes()).hexdigest() == evidence['source_sha256']
for i, command in enumerate(checks):
    run = subprocess.run(command, cwd=product, capture_output=True, text=True, timeout=8)
    print('public check', i, 'exit', run.returncode, run.stderr.strip())
    assert run.returncode == 0

def payload(events=None, balances=None):
    return {'balances': {'a': 2, 'b': 0} if balances is None else balances,
            'events': [] if events is None else events}

def event(i='x', a='a', d=-1, **extra):
    return {'id': i, 'account': a, 'delta': d, **extra}

valid = [
    ('empty', payload(balances={}), {'balances': {}, 'applied': [], 'replayed': []}),
    ('zero', payload([event(d=0)]), {'balances': {'a': 2, 'b': 0}, 'applied': ['x'], 'replayed': []}),
    ('repeated replay and extra keys', payload([event(note=1), event(note=2), event('y', 'b', 3), event(note=None), event('z', 'a', -1), event('y', 'b', 3)]),
     {'balances': {'a': 0, 'b': 3}, 'applied': ['x', 'y', 'z'], 'replayed': ['x', 'x', 'y']}),
    ('credit before debit', payload([event('credit', 'b', 3), event('debit', 'b', -3)]),
     {'balances': {'a': 2, 'b': 0}, 'applied': ['credit', 'debit'], 'replayed': []}),
    ('arbitrary precision', payload([event(d=10**100)], {'a': 10**100}),
     {'balances': {'a': 2 * 10**100}, 'applied': ['x'], 'replayed': []}),
]
valid[0][1]['extra'] = {'nested': [1, 2]}
invalid = [
    ('non-object', None),
    ('missing fields', {}),
    ('bad balances container', {'balances': [], 'events': []}),
    ('bad events container', {'balances': {}, 'events': {}}),
    ('negative initial', payload(balances={'a': -1})),
    ('boolean initial', payload(balances={'a': True})),
    ('float initial', payload(balances={'a': 2.0})),
    ('non-object event', payload([None])),
    ('empty id', payload([event(i='')])),
    ('non-string id', payload([event(i=1)])),
    ('empty account', payload([event(a='')])),
    ('non-string account', payload([event(a=[])])),
    ('unknown account', payload([event(a='missing')])),
    ('boolean delta', payload([event(d=True)])),
    ('float delta', payload([event(d=-1.0)])),
    ('missing delta', payload([{'id': 'x', 'account': 'a'}])),
    ('intermediate overdraft', payload([event('first', 'a', -3), event('later', 'a', 4)])),
    ('late overdraft', payload([event('first', 'a', -1), event('later', 'a', -2)])),
    ('delta conflict', payload([event(), event(d=0)])),
    ('account conflict', payload([event(), event(a='b')])),
    ('invalid boolean replay', payload([event(d=1), event(d=True)])),
    ('invalid float replay', payload([event(), event(d=-1.0)])),
    ('unknown account replay', payload([event(), event(a='missing')])),
    ('missing field replay', payload([event(), {'id': 'x', 'delta': -1}])),
]
for fn in (app.process, service.handle):
    for name, value, expected in valid:
        before = copy.deepcopy(value)
        result = fn(value)
        assert result == expected, (fn.__name__, name, result)
        assert value == before, (fn.__name__, name, 'mutated input')
        result['balances']['new'] = 1
        assert value == before, (fn.__name__, name, 'aliased balances')
    for name, value in invalid:
        before = copy.deepcopy(value)
        try:
            fn(value)
        except ValueError:
            pass
        else:
            raise AssertionError((fn.__name__, name, 'accepted invalid input'))
        assert value == before, (fn.__name__, name, 'mutated on rejection')

members = [value for _, value, _ in valid]
before = copy.deepcopy(members)
assert service.batch(members) == [expected for _, _, expected in valid]
assert members == before
assert service.batch([]) == []
for value in (None, {}, (), 'payloads'):
    try:
        service.batch(value)
    except ValueError:
        pass
    else:
        raise AssertionError('non-list batch accepted')
members = [payload([event()]), payload([event(d=-3)])]
before = copy.deepcopy(members)
try:
    service.batch(members)
except ValueError:
    pass
else:
    raise AssertionError('invalid batch member accepted')
assert members == before
assert service.batch([payload([event()]), payload([event()])]) == [
    {'balances': {'a': 1, 'b': 0}, 'applied': ['x'], 'replayed': []}] * 2

def cli(args, value=''):
    return subprocess.run([sys.executable, '-I', '-B', str(product / 'cli.py'), *args],
                          cwd=product, input=value, capture_output=True, text=True, timeout=5)

# -I removes the script directory; use the existing CLI invocation mode instead.
def cli(args, value=''):
    return subprocess.run([sys.executable, '-B', str(product / 'cli.py'), *args],
                          cwd=product, input=value, capture_output=True, text=True, timeout=5)

for name, value, expected in valid:
    result = cli([], json.dumps(value))
    assert result.returncode == 0 and not result.stderr, (name, result)
    assert json.loads(result.stdout) == expected, (name, result.stdout)
for name, value in invalid:
    result = cli([], json.dumps(value))
    assert result.returncode == 2 and not result.stdout and result.stderr.startswith('ERROR: '), (name, result)
result = cli(['--version'])
assert (result.returncode, result.stdout, result.stderr) == (0, 'api-v1\n', '')
for args in (['--unknown'], ['--version', 'extra'], ['--version', '--version']):
    result = cli(args)
    assert (result.returncode, result.stdout, result.stderr) == (2, '', 'ERROR: unsupported arguments\n')
print('PASS: public checks, 29 targeted cases across process/handle/CLI, batch order/rejection, and input immutability')
