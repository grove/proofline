import app


def handle(payload):
    return app.process(payload)


def batch(payloads):
    if not isinstance(payloads, list):
        raise ValueError("payloads must be a list")
    # Build a fresh result list. app.process only reads each payload, so both
    # the batch and its members remain untouched even if a later one is bad.
    return [app.process(payload) for payload in payloads]
