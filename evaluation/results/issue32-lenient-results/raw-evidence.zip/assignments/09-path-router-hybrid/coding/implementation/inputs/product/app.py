import re
from urllib.parse import unquote_to_bytes


_BAD_ESCAPE = re.compile(r"%(?![0-9A-Fa-f]{2})")


def _split_slash_value(value, description):
    if not value.startswith("/"):
        raise ValueError(f"{description} must begin with '/'")
    if value == "/":
        return []
    segments = value[1:].split("/")
    if any(segment == "" for segment in segments):
        raise ValueError(f"{description} contains an empty segment")
    return segments


def _decode_segment(segment):
    if _BAD_ESCAPE.search(segment):
        raise ValueError("path contains a malformed percent escape")
    try:
        return unquote_to_bytes(segment).decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise ValueError("path contains invalid UTF-8") from error


def _compile_route(route, index):
    if not isinstance(route, dict):
        raise ValueError("each route must be an object")
    pattern = route.get("pattern")
    name = route.get("name")
    if not isinstance(pattern, str):
        raise ValueError("route pattern must be a string")
    if not isinstance(name, str) or not name:
        raise ValueError("route name must be a nonempty string")

    raw_segments = _split_slash_value(pattern, "route pattern")
    segments = []
    capture_names = set()
    literal_count = 0
    wildcard = False
    for position, segment in enumerate(raw_segments):
        kind = "literal"
        capture_name = None
        if segment.startswith(":"):
            kind = "capture"
            capture_name = segment[1:]
        elif segment.startswith("*"):
            kind = "wildcard"
            capture_name = segment[1:]
            wildcard = True
            if position != len(raw_segments) - 1:
                raise ValueError("wildcard must be the last pattern segment")

        if kind != "literal":
            if not capture_name:
                raise ValueError("capture name must be nonempty")
            if capture_name in capture_names:
                raise ValueError("capture names must be unique within a pattern")
            capture_names.add(capture_name)
        else:
            literal_count += 1
        segments.append((kind, capture_name if kind != "literal" else segment))

    return {
        "name": name,
        "segments": segments,
        "literal_count": literal_count,
        "wildcard": wildcard,
        "segment_count": len(segments),
        "index": index,
    }


def _match(route, path_segments):
    pattern_segments = route["segments"]
    has_wildcard = route["wildcard"]
    fixed_count = len(pattern_segments) - (1 if has_wildcard else 0)
    if (has_wildcard and len(path_segments) < fixed_count) or (
        not has_wildcard and len(path_segments) != fixed_count
    ):
        return None

    params = {}
    for position, (kind, value) in enumerate(pattern_segments[:fixed_count]):
        path_segment = path_segments[position]
        if kind == "literal":
            if value != path_segment:
                return None
        else:
            params[value] = path_segment

    if has_wildcard:
        _, capture_name = pattern_segments[-1]
        params[capture_name] = path_segments[fixed_count:]
    return params


def process(payload):
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    routes = payload.get("routes")
    paths = payload.get("paths")
    if not isinstance(routes, list):
        raise ValueError("routes must be a list")
    if not isinstance(paths, list):
        raise ValueError("paths must be a list")

    # Compile every route before considering paths, so an unused invalid route
    # is still rejected.
    compiled_routes = [_compile_route(route, index)
                       for index, route in enumerate(routes)]
    decoded_paths = []
    for path in paths:
        if not isinstance(path, str):
            raise ValueError("each path must be a string")
        decoded_paths.append([_decode_segment(segment)
                              for segment in _split_slash_value(path, "path")])

    matches = []
    for path_segments in decoded_paths:
        winner = None
        winner_params = None
        winner_rank = None
        for route in compiled_routes:
            params = _match(route, path_segments)
            if params is None:
                continue
            rank = (route["literal_count"], not route["wildcard"],
                    route["segment_count"], -route["index"])
            if winner_rank is None or rank > winner_rank:
                winner = route
                winner_params = params
                winner_rank = rank
        if winner is None:
            matches.append(None)
        else:
            matches.append({"name": winner["name"], "params": winner_params})
    return {"matches": matches}
