import copy
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/grove/projects/proofline/.proofline/issue32-sol-luna-high-lenient/assignments/09-path-router-hybrid/verification/inputs/product')
sys.path.insert(0, str(ROOT))
import app
import service

count = 0

def route(pattern, name):
    return {'pattern': pattern, 'name': name, 'extra': {'allowed': True}}

def valid(routes, paths, matches):
    global count
    payload = {'routes': routes, 'paths': paths, 'extra': ['kept']}
    before = copy.deepcopy(payload)
    expected = {'matches': matches}
    for func in (app.process, service.handle):
        assert func(payload) == expected, (payload, func(payload), expected)
        assert payload == before
    assert service.batch([payload, payload]) == [expected, expected]
    assert payload == before
    count += 1

def match(name, **params):
    return {'name': name, 'params': params}

valid([], ['/', '/x', '/x'], [None, None, None])
valid([route('/', 'root'), route('/*tail', 'wild')], ['/', '/x/y'], [match('root'), match('wild', tail=['x', 'y'])])
valid([route('/a/*tail', 'wild')], ['/a', '/a/b/c', '/'], [match('wild', tail=[]), match('wild', tail=['b', 'c']), None])
valid([route('/:id', 'capture')], ['/', '/x', '/x/y'], [None, match('capture', id='x'), None])
valid([route('/*tail', 'wild'), route('/:id', 'capture')], ['/x'], [match('capture', id='x')])
valid([route('/a/:x/:y', 'fixed'), route('/a/b/*tail', 'literal')], ['/a/b/c'], [match('literal', tail=['c'])])
valid([route('/a/*tail', 'short'), route('/a/:id/*tail', 'long')], ['/a/x', '/a/x/y'], [match('long', id='x', tail=[]), match('long', id='x', tail=['y'])])
valid([route('/:first', 'earlier'), route('/:later', 'later'), route('/:first', 'earlier')], ['/x', '/x'], [match('earlier', first='x'), match('earlier', first='x')])
valid([route('/:id', 'capture')], ['/a%2Fb', '/%252F', '/a+b', '/%2B', '/%E2%82%AC', '/é', '/%00'], [match('capture', id='a/b'), match('capture', id='%2F'), match('capture', id='a+b'), match('capture', id='+'), match('capture', id='€'), match('capture', id='é'), match('capture', id='\0')])
valid([route('/%41', 'encoded'), route('/A', 'plain')], ['/%2541', '/%41', '/a'], [match('encoded'), match('plain'), None])
valid([route('/./..', 'dots'), route('/x?y#z', 'syntax')], ['/./..', '/x?y#z', '/x'], [match('dots'), match('syntax'), None])
valid([route('/:a/*b', 'mixed')], ['/x%2Fy/z%2Fw'], [match('mixed', a='x/y', b=['z/w'])])
valid([route('/:a:b', 'punctuation'), route('/:*', 'other')], ['/x'], [match('punctuation', **{'a:b': 'x'})])
valid([], [], [])

invalid = [None, [], 1, {}, {'routes': [], 'paths': None}, {'routes': (), 'paths': []}, {'routes': [], 'paths': [1]}]
for bad_route in [None, {}, {'pattern': '/', 'name': ''}, {'pattern': '/', 'name': 1}, {'pattern': 1, 'name': 'r'}]:
    invalid.append({'routes': [route('/', 'good'), bad_route], 'paths': []})
for pattern in ['', 'a', '//', '/a/', '/a//b', '/:', '/*', '/:x/:x', '/:x/*x', '/*tail/a', '/*a/*b']:
    invalid.append({'routes': [route(pattern, 'bad')], 'paths': []})
for path in ['', 'x', '//', '/a/', '/a//b', '/%', '/%0', '/%GG', '/%0G', '/%80', '/%C0%AF', '/%ED%A0%80', '/%F4%90%80%80', '/%E2%82', '/\ud800']:
    invalid.append({'routes': [], 'paths': [path]})
for payload in invalid:
    before = copy.deepcopy(payload)
    for func in (app.process, service.handle):
        try:
            func(payload)
        except ValueError:
            pass
        else:
            raise AssertionError(('accepted invalid', payload))
        assert payload == before
    batch = [{'routes': [route('/*tail', 'ok')], 'paths': ['/x']}, payload]
    before_batch = copy.deepcopy(batch)
    try:
        service.batch(batch)
    except ValueError:
        pass
    else:
        raise AssertionError(('batch accepted invalid', payload))
    assert batch == before_batch
    count += 1
for payloads in [None, {}, (), 'text', 1]:
    try:
        service.batch(payloads)
    except ValueError:
        pass
    else:
        raise AssertionError(('accepted non-list batch', payloads))
assert service.batch([]) == []
p1 = {'routes': [route('/', 'first')], 'paths': ['/']}
p2 = {'routes': [], 'paths': ['/']}
assert service.batch([p1, p2]) == [{'matches': [match('first')]}, {'matches': [None]}]

# Ensure returned wildcard lists are fresh even across duplicate input paths.
payload = {'routes': [route('/*tail', 'wild')], 'paths': ['/a', '/a']}
out = app.process(payload)
out['matches'][0]['params']['tail'].append('changed')
assert out['matches'][1]['params']['tail'] == ['a']
assert payload['paths'] == ['/a', '/a']

def cli(args=(), payload=None):
    return subprocess.run([sys.executable, '-B', str(ROOT / 'cli.py'), *args], input='' if payload is None else json.dumps(payload), capture_output=True, text=True, cwd=ROOT, timeout=5)
result = cli(['--version'])
assert (result.returncode, result.stdout, result.stderr) == (0, 'api-v1\n', '')
for args in [['--bad'], ['--version', 'extra'], ['extra'], ['--version', '--version']]:
    result = cli(args)
    assert (result.returncode, result.stdout, result.stderr) == (2, '', 'ERROR: unsupported arguments\n')
payload = {'routes': [route('/:id/*tail', 'cli')], 'paths': ['/a%2Fb/%E2%82%AC', '/x']}
result = cli(payload=payload)
assert result.returncode == 0 and not result.stderr, result
assert json.loads(result.stdout) == app.process(payload)
result = cli(payload={'routes': [], 'paths': ['/%GG']})
assert result.returncode == 2 and not result.stdout and result.stderr.startswith('ERROR: '), result

print(f'PASS: {count} routing/invalid-payload cases across process, handle and batch; batch order/type/errors; input/result independence; CLI JSON/version/unsupported args.')
