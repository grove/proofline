from urllib.parse import unquote_to_bytes


def _segments(value, label):
    if not isinstance(value, str) or not value.startswith("/"):
        raise ValueError(f"{label} must be a string beginning with /")
    if value == "/":
        return []
    segments = value[1:].split("/")
    if any(segment == "" for segment in segments):
        raise ValueError(f"{label} must not contain empty segments")
    return segments


def _compile_route(route, index):
    if not isinstance(route, dict):
        raise ValueError("each route must be an object")
    name = route.get("name")
    if not isinstance(name, str) or not name:
        raise ValueError("route name must be a nonempty string")

    segments = _segments(route.get("pattern"), "pattern")
    pattern = []
    captures = set()
    literals = 0
    wildcard = False
    for position, segment in enumerate(segments):
        kind = segment[0] if segment[0] in ":*" else "literal"
        if kind == "literal":
            literals += 1
            pattern.append((kind, segment))
            continue
        capture = segment[1:]
        if not capture or capture in captures:
            raise ValueError("capture names must be nonempty and unique")
        captures.add(capture)
        if kind == "*":
            if position != len(segments) - 1:
                raise ValueError("wildcard must be the last pattern segment")
            wildcard = True
        pattern.append((kind, capture))

    priority = (literals, not wildcard, len(pattern), -index)
    return priority, name, pattern


def _decode_path(path):
    decoded = []
    for segment in _segments(path, "path"):
        position = 0
        while position < len(segment):
            if segment[position] == "%":
                escape = segment[position + 1:position + 3]
                if len(escape) != 2 or any(
                    character not in "0123456789abcdefABCDEF"
                    for character in escape
                ):
                    raise ValueError("path contains a malformed percent escape")
                position += 3
            else:
                position += 1
        try:
            decoded.append(unquote_to_bytes(segment).decode("utf-8", "strict"))
        except UnicodeError as error:
            raise ValueError("path segments must contain valid UTF-8") from error
    return decoded


def _match(pattern, segments):
    params = {}
    for position, (kind, value) in enumerate(pattern):
        if kind == "*":
            params[value] = segments[position:]
            return params
        if position >= len(segments):
            return None
        if kind == "literal":
            if value != segments[position]:
                return None
        else:
            params[value] = segments[position]
    return params if len(pattern) == len(segments) else None


def process(payload):
    """Validate and match routes against paths without changing the payload."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    routes = payload.get("routes")
    paths = payload.get("paths")
    if not isinstance(routes, list) or not isinstance(paths, list):
        raise ValueError("routes and paths must be lists")

    # Compile every route before matching, including routes that cannot win.
    compiled = [_compile_route(route, index) for index, route in enumerate(routes)]
    compiled.sort(key=lambda route: route[0], reverse=True)
    matches = []
    for path in paths:
        segments = _decode_path(path)
        match = None
        for _, name, pattern in compiled:
            params = _match(pattern, segments)
            if params is not None:
                match = {"name": name, "params": params}
                break
        matches.append(match)
    return {"matches": matches}
