import copy
import json
import pathlib
import subprocess
import sys
import unittest

import app
import service


def route(pattern, name="route"):
    return {"pattern": pattern, "name": name}


class Router(unittest.TestCase):
    def test_root_captures_and_wildcard_remainder(self):
        payload = {
            "routes": [route("/", "root"), route("/a/:id/*tail", "nested")],
            "paths": ["/", "/a/x", "/a/x/y/z", "/a", "/elsewhere"],
        }
        self.assertEqual(app.process(payload), {"matches": [
            {"name": "root", "params": {}},
            {"name": "nested", "params": {"id": "x", "tail": []}},
            {"name": "nested", "params": {"id": "x", "tail": ["y", "z"]}},
            None, None,
        ]})
        self.assertEqual(app.process({"routes": [route("/*tail")], "paths": ["/"]}),
                         {"matches": [{"name": "route", "params": {"tail": []}}]})

    def test_priority_rules(self):
        cases = [
            ([route("/:a/:b", "exact"), route("/fixed/*tail", "literal")],
             "/fixed/x", {"name": "literal", "params": {"tail": ["x"]}}),
            ([route("/*tail", "wild"), route("/:id", "single")],
             "/x", {"name": "single", "params": {"id": "x"}}),
            ([route("/:a/:b/*tail", "long"), route("/:a/:b", "exact")],
             "/x/y", {"name": "exact", "params": {"a": "x", "b": "y"}}),
            ([route("/a/*tail", "short"), route("/a/:id/*tail", "long")],
             "/a/x", {"name": "long", "params": {"id": "x", "tail": []}}),
            ([route("/a/:id", "first"), route("/:id/b", "second")],
             "/a/b", {"name": "first", "params": {"id": "b"}}),
            ([route("/x", "first"), route("/x", "second")],
             "/x", {"name": "first", "params": {}}),
        ]
        for routes, path, expected in cases:
            with self.subTest(routes=routes):
                self.assertEqual(app.process({"routes": routes, "paths": [path]}),
                                 {"matches": [expected]})

    def test_decoding_and_literal_syntax(self):
        payload = {
            "routes": [route("/:id/*tail")],
            "paths": ["/%2f/%252F/+/%2B/caf%C3%A9/雪", "/a?b#c/./.."],
        }
        self.assertEqual(app.process(payload), {"matches": [
            {"name": "route", "params": {
                "id": "/", "tail": ["%2F", "+", "+", "café", "雪"]}},
            {"name": "route", "params": {"id": "a?b#c", "tail": [".", ".."]}},
        ]})
        self.assertEqual(app.process({
            "routes": [route("/%2F"), route("/A?b#c", "syntax"), route("/..", "dot")],
            "paths": ["/%252F", "/%2F", "/A?b#c", "/a?b#c", "/.."],
        }), {"matches": [
            {"name": "route", "params": {}}, None,
            {"name": "syntax", "params": {}}, None,
            {"name": "dot", "params": {}},
        ]})

    def test_invalid_paths_even_without_routes(self):
        paths = [None, 1, [], "", "a", "//", "/a/", "/a//b", "/%", "/%0",
                 "/%GG", "/%0g", "/%FF", "/%C0%AF", "/%E2%82",
                 "/%ED%A0%80", "/%F4%90%80%80", "/\ud800"]
        for path in paths:
            with self.subTest(path=repr(path)), self.assertRaises(ValueError):
                app.process({"routes": [], "paths": [path]})

    def test_validate_all_routes_even_when_unused(self):
        invalid = [None, [], {}, route("/", ""), route("/", None),
                   route(None), route(""), route("a"), route("//"), route("/a/"),
                   route("/a//b"), route("/:"), route("/*"), route("/:x/:x"),
                   route("/:x/*x"), route("/*tail/a"), route("/*x/*y")]
        for bad_route in invalid:
            for paths in ([], ["/ok"]):
                with self.subTest(route=bad_route, paths=paths), self.assertRaises(ValueError):
                    app.process({"routes": [route("/ok"), bad_route], "paths": paths})

    def test_payload_validation(self):
        invalid = [None, [], "", {}, {"routes": []}, {"paths": []},
                   {"routes": (), "paths": []}, {"routes": [], "paths": ()},
                   {"routes": {}, "paths": []}, {"routes": [], "paths": "x"}]
        for payload in invalid:
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                app.process(payload)

    def test_repeats_extra_keys_and_no_mutation(self):
        payload = {
            "routes": [{"pattern": "/:x/*tail", "name": " ", "extra": [1]},
                       route("/:x/*tail", "duplicate")],
            "paths": ["/a/b", "/a/b"], "extra": {"nested": [2]},
        }
        before = copy.deepcopy(payload)
        result = app.process(payload)
        self.assertEqual(result, {"matches": [
            {"name": " ", "params": {"x": "a", "tail": ["b"]}},
            {"name": " ", "params": {"x": "a", "tail": ["b"]}},
        ]})
        result["matches"][0]["params"]["tail"].append("changed")
        self.assertEqual(result["matches"][1]["params"]["tail"], ["b"])
        self.assertEqual(payload, before)
        payload["paths"].append("/%GG")
        before = copy.deepcopy(payload)
        with self.assertRaises(ValueError):
            app.process(payload)
        self.assertEqual(payload, before)


class Interfaces(unittest.TestCase):
    def test_handle_and_batch_order(self):
        payloads = [
            {"routes": [route("/:x")], "paths": ["/one"]},
            {"routes": [], "paths": ["/two"]},
            {"routes": [route("/")], "paths": []},
        ]
        before = copy.deepcopy(payloads)
        expected = [{"matches": [{"name": "route", "params": {"x": "one"}}]},
                    {"matches": [None]}, {"matches": []}]
        self.assertEqual(service.handle(payloads[0]), expected[0])
        self.assertEqual(service.batch(payloads), expected)
        self.assertEqual(service.batch([]), [])
        self.assertEqual(payloads, before)

    def test_invalid_batch_and_error_immutability(self):
        valid = {"routes": [route("/*tail")], "paths": ["/a"]}
        invalid = [None, {}, "", (), [valid, None],
                   [valid, {"routes": [route("/:")], "paths": []}],
                   [valid, {"routes": [], "paths": ["/%FF"]}]]
        for payloads in invalid:
            before = copy.deepcopy(payloads)
            with self.subTest(payloads=payloads), self.assertRaises(ValueError):
                service.batch(payloads)
            self.assertEqual(payloads, before)

    def test_cli_json_errors_and_unsupported_arguments(self):
        repo = pathlib.Path(__file__).resolve().parents[1]

        def run(payload, *args):
            return subprocess.run([sys.executable, "-B", str(repo / "cli.py"), *args],
                                  input=json.dumps(payload), cwd=repo,
                                  capture_output=True, text=True, timeout=5)

        payload = {"routes": [route("/:id")], "paths": ["/caf%C3%A9"]}
        result = run(payload)
        self.assertEqual((result.returncode, result.stderr), (0, ""))
        self.assertEqual(json.loads(result.stdout), app.process(payload))
        result = run({"routes": [], "paths": ["/%FF"]})
        self.assertEqual((result.returncode, result.stdout), (2, ""))
        self.assertTrue(result.stderr.startswith("ERROR: "))
        for args in [("--unknown",), ("--version", "extra")]:
            result = run(payload, *args)
            self.assertEqual((result.returncode, result.stdout, result.stderr),
                             (2, "", "ERROR: unsupported arguments\n"))
