def process(payload):
    """Apply ledger events without changing the caller's payload."""
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if "balances" not in payload or "events" not in payload:
        raise ValueError("payload must contain balances and events")

    source_balances = payload["balances"]
    events = payload["events"]
    if not isinstance(source_balances, dict):
        raise ValueError("balances must be an object")
    if not isinstance(events, list):
        raise ValueError("events must be a list")

    balances = {}
    for account, balance in source_balances.items():
        if not isinstance(account, str) or not account:
            raise ValueError("account names must be nonempty strings")
        if isinstance(balance, bool) or not isinstance(balance, int) or balance < 0:
            raise ValueError("balances must be nonnegative integers")
        balances[account] = balance

    applied = []
    replayed = []
    seen = {}
    for event in events:
        if not isinstance(event, dict):
            raise ValueError("each event must be an object")
        if not all(key in event for key in ("id", "account", "delta")):
            raise ValueError("each event must contain id, account, and delta")

        event_id = event["id"]
        account = event["account"]
        delta = event["delta"]
        if not isinstance(event_id, str) or not event_id:
            raise ValueError("event ids must be nonempty strings")
        if not isinstance(account, str) or not account:
            raise ValueError("account names must be nonempty strings")
        if isinstance(delta, bool) or not isinstance(delta, int):
            raise ValueError("event deltas must be integers")
        if account not in balances:
            raise ValueError("event account does not exist")

        identity = (account, delta)
        if event_id in seen:
            if seen[event_id] != identity:
                raise ValueError("conflicting replay")
            replayed.append(event_id)
            continue

        next_balance = balances[account] + delta
        if next_balance < 0:
            raise ValueError("event would make balance negative")
        balances[account] = next_balance
        seen[event_id] = identity
        applied.append(event_id)

    return {"balances": balances, "applied": applied, "replayed": replayed}
