The entire original source controls. No earlier acceptance plan is supplied.
