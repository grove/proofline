def name(x): return isinstance(x,str) and bool(x)
def integer(x): return type(x) is int
def process(p):
    if not isinstance(p,dict): raise ValueError()

    import re
    from urllib.parse import unquote
    routes,paths=p.get('routes'),p.get('paths')
    if not isinstance(routes,list) or not isinstance(paths,list): raise ValueError()
    def split(s):
        if not isinstance(s,str) or not s.startswith('/'): raise ValueError()
        bits=[] if s=='/' else s[1:].split('/')
        if any(not b for b in bits): raise ValueError()
        return bits
    parsed=[]
    for r in routes:
        if not isinstance(r,dict) or not name(r.get('name')): raise ValueError()
        bits=split(r.get('pattern')); names=[]
        for i,b in enumerate(bits):
            if b.startswith((':','*')):
                if len(b)==1 or b[1:] in names or (b[0]=='*' and i!=len(bits)-1): raise ValueError()
                names.append(b[1:])
        rank=(sum(not b.startswith((':','*')) for b in bits),not any(b.startswith('*') for b in bits),len(bits))
        parsed.append((rank,bits,r['name']))
    matches=[]
    for path in paths:
        raw=split(path)
        if any(re.search(r'%(?![0-9a-fA-F]{2})',b) for b in raw): raise ValueError()
        try: segments=[unquote(b,encoding='utf-8',errors='strict') for b in raw]
        except UnicodeError: raise ValueError()
        options=[]
        for rank,bits,label in parsed:
            params={}; position=0; good=True
            for b in bits:
                if b.startswith('*'): params[b[1:]]=segments[position:]; position=len(segments)
                elif position>=len(segments): good=False; break
                elif b.startswith(':'): params[b[1:]]=segments[position]; position+=1
                elif b==segments[position]: position+=1
                else: good=False; break
            if good and position==len(segments): options.append((rank,{'name':label,'params':params}))
        matches.append(options[0][1] if options else None)
    return {'matches':matches}
