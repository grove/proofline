def name(x): return isinstance(x,str) and bool(x)
def integer(x): return type(x) is int
def process(p):
    if not isinstance(p,dict): raise ValueError()

    tiers,items,discount=p.get('tiers'),p.get('items'),p.get('discount_bps')
    if not isinstance(tiers,list) or not tiers or not isinstance(items,list) or not integer(discount) or not 0<=discount<=10000: raise ValueError()
    previous=0
    for i,t in enumerate(tiers):
        if not isinstance(t,dict) or not integer(t.get('cents')) or t['cents']<0 or 'limit' not in t: raise ValueError()
        limit=t['limit']
        if i==len(tiers)-1:
            if limit is not None: raise ValueError()
        elif not integer(limit) or limit<=previous: raise ValueError()
        if limit is not None: previous=limit
    amounts=[]
    for item in items:
        if not isinstance(item,dict) or not name(item.get('id')) or not integer(item.get('units')) or item['units']<0: raise ValueError()
        units=item['units']; raw=0; previous=0
        for t in tiers:
            used=units if t['limit'] is None else min(units,t['limit']-previous)
            raw+=used*t['cents']; units-=used
            if t['limit'] is not None: previous=t['limit']
        amounts.append(raw*(10000-discount))
    total=(sum(amounts)+5000)//10000
    allocations=[a//10000 for a in amounts]
    order=sorted(range(len(amounts)),key=lambda i:(-(amounts[i]%10000),i))
    for i in order[:total-sum(allocations)]: allocations[i]+=1
    return {'items':[{'id':item['id'],'cents':value} for item,value in zip(items,allocations)],'total_cents':total}
