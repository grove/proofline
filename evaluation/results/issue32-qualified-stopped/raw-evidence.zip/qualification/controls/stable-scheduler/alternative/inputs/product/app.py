def name(x): return isinstance(x,str) and bool(x)
def integer(x): return type(x) is int
def process(p):
    if not isinstance(p,dict): raise ValueError()

    workers,tasks=p.get('workers'),p.get('tasks')
    if not integer(workers) or workers<=0 or not isinstance(tasks,list): raise ValueError()
    ids=[]
    for t in tasks:
        if not isinstance(t,dict) or not name(t.get('id')) or not integer(t.get('duration')) or t['duration']<0 or not isinstance(t.get('requires'),list) or any(not name(d) for d in t['requires']): raise ValueError()
        ids.append(t['id'])
    if len(set(ids))!=len(ids) or any(d not in ids for t in tasks for d in t['requires']): raise ValueError()
    time=0; done=set(); launched=set(); active={}; schedule=[]
    while len(done)<len(tasks):
        for worker,(finish,key) in list(active.items()):
            if finish==time: done.add(key); del active[worker]
        ready=min((t for t in tasks if t['id'] not in launched and set(t['requires'])<=done),key=lambda t:ids.index(t['id']),default=None)
        idle=next((w for w in range(workers) if w not in active),None)
        if ready is not None and idle is not None:
            key=ready['id']; finish=time+ready['duration']; launched.add(key)
            schedule.append({'id':key,'start':time,'finish':finish,'worker':idle})
            if finish==time: done.add(key)
            else: active[idle]=(finish,key)
        elif active: time=min(f for f,k in active.values())
        elif len(done)<len(tasks): raise ValueError()
    return {'schedule':schedule}
