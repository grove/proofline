def name(x): return isinstance(x,str) and bool(x)
def integer(x): return type(x) is int
def process(p):
    if not isinstance(p,dict): raise ValueError()

    balances, events = p.get('balances'), p.get('events')
    if not isinstance(balances,dict) or not isinstance(events,list): raise ValueError()
    if any(not name(k) or not integer(v) or v<0 for k,v in balances.items()): raise ValueError()
    stock=dict(balances); seen={}; applied=[]; replayed=[]
    for e in events:
        if not isinstance(e,dict) or not name(e.get('id')) or not name(e.get('account')) or e['account'] not in balances or not integer(e.get('delta')): raise ValueError()
        key=e['id']; signature=(e['account'],e['delta'])
        if key in seen:
            if seen[key]!=signature: raise ValueError()
            replayed.append(key); continue
        account,delta=signature
        if stock[account]+delta<0: raise ValueError()
        stock[account]+=delta; seen[key]=signature; applied.append(key)
    return {'balances':stock,'applied':applied,'replayed':replayed}
