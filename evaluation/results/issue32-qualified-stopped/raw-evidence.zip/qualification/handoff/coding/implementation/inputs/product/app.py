def process(p): return 0
