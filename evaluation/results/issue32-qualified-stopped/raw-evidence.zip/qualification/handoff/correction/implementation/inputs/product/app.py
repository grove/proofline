def process(p): return 42
