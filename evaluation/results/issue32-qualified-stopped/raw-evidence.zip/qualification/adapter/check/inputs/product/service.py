import app


def handle(payload):
    return app.process(payload)


def batch(payloads):
    if not isinstance(payloads,list): raise ValueError()
    return [handle(p) for p in payloads]
