def name(x): return isinstance(x,str) and bool(x)
def integer(x): return type(x) is int
def process(p):
    if not isinstance(p,dict): raise ValueError()

    balances, events = p.get("balances"), p.get("transfers")
    if not isinstance(balances, dict) or not isinstance(events, list): raise ValueError()
    if any(not name(k) or not integer(v) or v < 0 for k,v in balances.items()): raise ValueError()
    for e in events:
        if not isinstance(e,list) or len(e)!=3: raise ValueError()
        a,b,n=e
        if not name(a) or not name(b) or a not in balances or b not in balances or not integer(n) or n<0: raise ValueError()

    stock=dict(balances)
    for a,b,n in events:
        if stock[a]<n: raise ValueError()
        stock[a]-=n; stock[b]+=n
    return {"balances":stock}
