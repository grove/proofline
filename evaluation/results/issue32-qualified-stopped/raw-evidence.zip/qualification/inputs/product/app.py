disposable S0 write canary
