"""Continue issue #32 using its frozen runner and corrected catalog qualification."""
import json
import os
from pathlib import Path
import time
import zipfile

from checks import codex_catalog
from checks.native_checks import write_record
from evaluation.sol_luna import grader, study as original

HERE = Path(__file__).resolve().parent
STORE = original.ROOT / '.proofline/issue32-sol-luna-high-qualified'
runner = grader.bound_module(original, HERE=HERE, STORE=STORE)
runner.native_boundary = grader.bound_module(original.infrastructure,
    corpus=original.corpus, grader=grader, STORE=STORE)


def catalog_readback(directory):
    # The denial canary needs a real result file; the old runner writes it only in finally.
    write_record(directory/'results.json', {'status': 'PREPARING', 'model_dispatches': 0,
                                          'assignments': runner.ledger()})
    return codex_catalog.readback(runner.CODEX, HERE/'model-catalog.json',
                                 runner.protocol()['models'], directory)


runner.catalog_readback = catalog_readback


def handoff_control():
    """Same four-call control, with declared startup-inclusive qualification limits."""
    folder = STORE/'qualification/handoff'
    seed = folder/'seed/product'
    seed.mkdir(parents=True)
    (seed/'app.py').write_text('def process(p): return 0\n')
    runner.host.git(seed,'init','--quiet','--template=')
    runner.snapshots.freeze(seed)
    source = ('Native handoff qualification only: app.process({}) must ultimately return 42. '
        'On the FIRST implementation turn retain return 0 deliberately and report completed=true, '
        'so the host can observe the concrete assertion defect. On the one resumed correction return 42. '
        'Planning and review must preserve these staged instructions. No unrelated effects.\n')
    checks = [[str(Path(runner.sys.executable).resolve()),'-B','-c','from app import process; assert process({}) == 42']]
    limits = runner.protocol()['limits']
    began = time.monotonic()
    deadline = began+limits['handoff_seconds']
    def budget():
        remaining = min(limits['handoff_model_seconds_per_call'],deadline-time.monotonic())
        if remaining <= 0:
            raise ValueError('Handoff qualification budget exhausted')
        return remaining
    control = {'status':'STARTED','stages':[],'arm':'hybrid','cost_usd':None,
        'scope':'Native model/Intentline/Proofline handoff qualification; no efficacy observation'}
    def observed(stage):
        control['stages'].append(stage)
        if stage['status'] != 'OBSERVED':
            raise ValueError('Native handoff stage incomplete: '+stage.get('error','unknown'))
    try:
        plan = runner.advisory('planning',source,seed,folder/'planning',budget(),checks)
        observed(plan)
        package = runner.adapter.load_export(folder/'planning/scratch/export',source,checks)
        first = runner.implement(source,seed,folder/'coding','luna',budget(),checks,
            plan={'metadata':package['metadata'],'contract':runner.adapter.parse(package['files']['contract.json'],'contract.json')},persist=True)
        if not first['stages']:
            raise ValueError('Native Luna implementation unavailable')
        observed(first['stages'][0])
        if not first['accepted']:
            raise ValueError('Initial Luna control did not complete')
        candidate = Path(first['candidate'])
        failed = runner.checked(candidate,source,checks,folder/'failed-check',budget())
        review = runner.advisory('verification',source,candidate,folder/'verification',budget(),checks,failed)
        observed(review)
        if (not runner.review_valid(review,source,1) or
                not runner.correction_allowed(failed,folder/'failed-check',checks,candidate)):
            raise ValueError('Sol review or trustworthy defect handoff failed')
        if len({plan['thread_id'],first['stages'][0]['thread_id'],review['thread_id']}) != 3:
            raise ValueError('Planning, implementation and independent review must use distinct native threads')
        def correction_dispatch():
            if not runner.correction_allowed(failed,folder/'failed-check',checks,candidate):
                raise ValueError('Handoff correction evidence changed')
        corrected = runner.implement(source,candidate,folder/'correction','luna',budget(),checks,
            session_id=first['stages'][0]['thread_id'],
            guidance={'feedback':failed['feedback'],'Sol_advice_not_proof':review['report']['findings']},
            on_dispatch=correction_dispatch)
        if not corrected['stages']:
            raise ValueError('Native same-Luna correction unavailable')
        observed(corrected['stages'][0])
        if corrected['stages'][0]['thread_id'] != first['stages'][0]['thread_id']:
            raise ValueError('Correction must retain the original Luna thread')
        final = runner.checked(Path(corrected['candidate']),source,checks,folder/'final-check',budget())
        if final['status'] != 'CHECKS PASSED' or not corrected['accepted'] or time.monotonic() > deadline:
            raise ValueError('Same-Luna correction/recheck qualification failed')
        control['status'] = 'OBSERVED'
    except Exception as error:
        control.update(status='STOPPED',blocker=str(error))
        raise
    finally:
        runner.recover_stages(folder,control)
        control.update(model_dispatches=len(control['stages']),elapsed_seconds=time.monotonic()-began)
        write_record(folder/'result.json',control)


def approved():
    """Authorization binds this freeze and its actual declared campaign limit."""
    approval = json.loads((STORE/'approval.json').read_text()) if (STORE/'approval.json').exists() else {}
    limits = runner.protocol()['limits']
    if (approval.get('freeze_sha256') != runner.identities()['freeze_sha256'] or
            approval.get('study_id') != runner.protocol()['study_id'] or
            approval.get('max_native_dispatches') != limits['max_native_dispatches'] or
            approval.get('max_seconds') != limits['max_campaign_seconds'] or
            not isinstance(approval.get('user_authorization'),str) or not approval['user_authorization'].strip()):
        raise ValueError('Explicit authorization required for this fresh freeze and declared live limits')
    return approval


def publish_record(destination):
    """Archive the continuation freeze under its own path, retaining the original."""
    destination.mkdir(parents=True,exist_ok=False)
    with zipfile.ZipFile(destination/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(STORE.rglob('*')):
            name = path.relative_to(STORE)
            if 'catalog-state' in name.parts:
                continue
            if path.is_symlink():
                entry = zipfile.ZipInfo(str(name))
                entry.create_system = 3
                entry.external_attr = 0o120777 << 16
                archive.writestr(entry,os.readlink(path))
            elif path.is_file():
                archive.write(path,str(name))
                if path.parent == STORE and path.suffix == '.json':
                    (destination/path.name).write_bytes(path.read_bytes())
    with zipfile.ZipFile(destination/'frozen-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for name in json.loads((HERE/'FREEZE.json').read_text())['sha256']:
            archive.write(runner.ROOT/name,name)
        archive.write(HERE/'FREEZE.json',str((HERE/'FREEZE.json').relative_to(runner.ROOT)))
        for name,path in runner.infrastructure.producer_files().items():
            archive.write(path,'intentline/'+name)
        archive.write(runner.infrastructure.PRODUCER/'LICENSE','intentline/LICENSE')
    write_record(destination/'hashes.json',{str(p.relative_to(destination)):runner.host.sha256(p.read_bytes())
        for p in destination.rglob('*') if p.is_file()})


runner.handoff_control = handoff_control
runner.approved = approved
runner.publish_record = publish_record


if __name__ == '__main__':
    raise SystemExit(runner.main())
