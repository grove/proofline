"""Continue issue #32 using its frozen runner and corrected catalog qualification."""
from pathlib import Path

from checks import codex_catalog
from evaluation.sol_luna import grader, study as original

HERE = Path(__file__).resolve().parent
STORE = original.ROOT / '.proofline/issue32-sol-luna-high-host'
runner = grader.bound_module(original, HERE=HERE, STORE=STORE)
runner.native_boundary = grader.bound_module(original.infrastructure,
    corpus=original.corpus, grader=grader, STORE=STORE)


def catalog_readback(directory):
    return codex_catalog.readback(runner.CODEX, HERE/'model-catalog.json',
                                 runner.protocol()['models'], directory)


runner.catalog_readback = catalog_readback


if __name__ == '__main__':
    raise SystemExit(runner.main())
