# idempotent-ledger
Implement ../source.md.
