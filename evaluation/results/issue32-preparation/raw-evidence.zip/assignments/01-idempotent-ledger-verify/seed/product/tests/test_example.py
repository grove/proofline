import unittest
from app import process
class Example(unittest.TestCase):
    def test_example(self):
        self.assertEqual(process({'balances': {'a': 3}, 'events': [{'id': 'x', 'account': 'a', 'delta': -1}]}),{'balances': {'a': 2}, 'applied': ['x'], 'replayed': []})
