Implement {"balances": {account: nonnegative integer}, "events":
[{"id": nonempty string, "account": nonempty string, "delta": integer}, ...]}.
Booleans are invalid numbers. Every account must already exist. Apply unique
event IDs in order, rejecting any intermediate negative balance with ValueError.
An identical replay (same id, account and delta, ignoring extra keys) is skipped;
a conflicting replay raises ValueError. Validate every record, including replays.
Return {"balances": final balances, "applied": unique IDs in application order,
"replayed": skipped IDs in occurrence order, including repetitions}.
Empty containers and zero deltas are valid. Never partially mutate on rejection.
Example: balance a=2, events x/a/-1 twice => balance a=1, applied [x], replayed [x].

Expose the same behavior through app.process, service.handle and the existing
JSON stdin/stdout CLI. Add service.batch(payloads): return each process result
in input order; reject a non-list or any invalid member with ValueError.
Do not mutate any input, including on errors. Preserve the exact CLI --version
response and unsupported-argument behavior; keep cli.py unchanged. Extra object
keys are allowed. Update a stale test expectation if it contradicts this request.
