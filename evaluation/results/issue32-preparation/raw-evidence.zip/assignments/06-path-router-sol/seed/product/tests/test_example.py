import unittest
from app import process
class Example(unittest.TestCase):
    def test_example(self):
        self.assertEqual(process({'routes': [{'pattern': '/a/:id', 'name': 'user'}], 'paths': ['/a/x', '/b']}),{'matches': [{'name': 'user', 'params': {'id': 'x'}}, None]})
