Implement {"routes": [{"pattern": string, "name": nonempty string}, ...],
"paths": [string, ...]}. Patterns and paths begin with /; / is zero segments.
Otherwise empty segments (including trailing /) are invalid. Pattern segments
are literals, :name captures one segment, or *name captures the remaining list
(possibly empty). Capture names are nonempty, unique within a pattern; * is last.
Split paths on / BEFORE percent decoding each segment exactly once as strict
UTF-8. Reject malformed percent escapes/UTF-8. Plus is literal plus. An encoded
slash stays inside its decoded segment. Do not decode pattern literals, normalize
dot segments, fold case, or parse query/fragment syntax. A bare : or * is invalid.
For each path choose the matching route with most literal segments, then prefer
no wildcard, then most pattern segments, then earliest original route. Return
{"matches": [{"name": route name, "params": captures}, ...]}, using null for no
match. Repeated paths/routes are allowed. Validate ALL routes even if unused.
Example: routes /*tail and /:id, path /x => :id wins, params {"id":"x"}.

Expose the same behavior through app.process, service.handle and the existing
JSON stdin/stdout CLI. Add service.batch(payloads): return each process result
in input order; reject a non-list or any invalid member with ValueError.
Do not mutate any input, including on errors. Preserve the exact CLI --version
response and unsupported-argument behavior; keep cli.py unchanged. Extra object
keys are allowed. Update a stale test expectation if it contradicts this request.
