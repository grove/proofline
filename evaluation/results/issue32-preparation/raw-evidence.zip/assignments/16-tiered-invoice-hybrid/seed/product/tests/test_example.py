import unittest
from app import process
class Example(unittest.TestCase):
    def test_example(self):
        self.assertEqual(process({'tiers': [{'limit': 2, 'cents': 3}, {'limit': None, 'cents': 1}], 'items': [{'id': 'a', 'units': 4}], 'discount_bps': 0}),{'items': [{'id': 'a', 'cents': 8}], 'total_cents': 8})
