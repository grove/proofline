Implement {"tiers": [{"limit": positive integer or null, "cents":
nonnegative integer}, ...], "items": [{"id": nonempty string, "units":
nonnegative integer}, ...], "discount_bps": integer from 0 through 10000}.
Booleans are invalid numbers. Tiers are nonempty, strictly increasing cumulative
limits; ONLY the last limit is null, and it MUST be null. Validate even unused
tiers/items. Charge each item's units independently through graduated tiers:
the first limit units at its price, the next limit minus previous at its price,
and the remaining units at the final price. Item IDs may repeat; preserve rows.
Discount each raw charge by multiplying by (10000-discount_bps)/10000 using exact
integer arithmetic. Round the SUM of discounted charges to nearest cent, halves
UP. Allocate that total to rows: floor each discounted charge, then award one
cent to the largest fractional remainders, ties to earlier input row. Never
round each line separately or use floating point. Return {"items": [{"id": ID,
"cents": allocated integer}, ...], "total_cents": sum of allocations}.
Empty items are allowed. Example: three 1-cent rows, 5000 bps => [1,1,0], total 2.

Expose the same behavior through app.process, service.handle and the existing
JSON stdin/stdout CLI. Add service.batch(payloads): return each process result
in input order; reject a non-list or any invalid member with ValueError.
Do not mutate any input, including on errors. Preserve the exact CLI --version
response and unsupported-argument behavior; keep cli.py unchanged. Extra object
keys are allowed. Update a stale test expectation if it contradicts this request.
