Implement {"workers": positive integer, "tasks": [{"id": nonempty string,
"duration": nonnegative integer, "requires": [task ID, ...]}, ...]}.
Booleans are invalid numbers. IDs are unique; dependencies must exist. Duplicate
dependencies have no effect. Reject self-dependencies and ANY cycle, including
disconnected cycles, with ValueError. Empty tasks are allowed.
Start at time 0 with workers numbered 0..workers-1. Release ALL completions at
the current time before dispatch. Repeatedly dispatch the earliest ORIGINAL
ready, undispatched task to the lowest idle worker. Zero-duration work completes
immediately before choosing the next task at that same time. Otherwise advance
to the next completion only when no further dispatch is possible. Return
{"schedule": [{"id": ID, "start": integer, "finish": integer, "worker": integer},
...]} in DISPATCH order. Do not sort by ID or finish time.
Example: one worker, tasks z/0/[] and a/1/[z] => z at 0..0 then a at 0..1.

Expose the same behavior through app.process, service.handle and the existing
JSON stdin/stdout CLI. Add service.batch(payloads): return each process result
in input order; reject a non-list or any invalid member with ValueError.
Do not mutate any input, including on errors. Preserve the exact CLI --version
response and unsupported-argument behavior; keep cli.py unchanged. Extra object
keys are allowed. Update a stale test expectation if it contradicts this request.
