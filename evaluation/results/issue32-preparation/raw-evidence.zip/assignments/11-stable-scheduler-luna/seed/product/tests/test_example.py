import unittest
from app import process
class Example(unittest.TestCase):
    def test_example(self):
        self.assertEqual(process({'workers': 1, 'tasks': [{'id': 'b', 'duration': 2, 'requires': []}, {'id': 'a', 'duration': 1, 'requires': ['b']}]}),{'schedule': [{'id': 'b', 'start': 0, 'finish': 2, 'worker': 0}, {'id': 'a', 'start': 2, 'finish': 3, 'worker': 0}]})
