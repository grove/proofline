import json, unittest
suite = unittest.defaultTestLoader.loadTestsFromNames(['tests.test_promise_evidence.SourceBoundMapping.test_green_suite_does_not_convert_unlinked_unicode_into_coverage'])
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({"tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": [[str(test), reason] for test, reason in result.skipped]}))
raise SystemExit(0 if result.wasSuccessful() else 1)
