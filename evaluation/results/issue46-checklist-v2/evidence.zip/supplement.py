"""Targeted authored-fixture correction and remaining no-model observations.
Prior failures are retained. This is not a replay of the full qualification.
"""
import json
from pathlib import Path
import time
from checks.native_checks import write_record
from evaluation.checklist import study
from evaluation.sol_luna.grader import bound_module
from evaluation.matched import study as boundaries

began = time.monotonic()
directory = study.STORE / 'supplement-final'
directory.mkdir(exist_ok=False)
rows = []
for issue, kind in ((13, 'alternative'), (14, 'substantive-defect'), (13, 'substantive-defect')):
    task = next(t for t in study.protocol()['tasks'] if t['issue'] == issue)
    folder = directory / str(issue) / kind
    product = study.existing.seed(task, folder / 'product', reference=True)
    spec = json.loads((study.HERE / 'regression-controls.json').read_text())[str(issue)]
    if kind == 'alternative':
        study.variant(product, issue, kind)
        modules = spec['modules']
    else:
        edit = spec['defect']; path = product / edit['path']; raw = path.read_text()
        assert raw.count(edit['old']) == 1
        path.write_text(raw.replace(edit['old'], edit['new']))
        study.snapshots.freeze(product)
        modules = [spec['negative_test']]
    observation = study.regression_control(product, modules, folder / 'regressions',
                                           began+300, expected_pass=kind == 'alternative')
    rows.append({'issue': issue, 'kind': kind, 'tree': study.host.git(product,'rev-parse','HEAD^{tree}'),
                 'observation': observation})
    write_record(directory / 'regressions.json', rows)
    assert observation['matched'], observation
inputs = directory / 'boundary/inputs'
inputs.mkdir(parents=True)
study.existing.seed(study.protocol()['tasks'][0], inputs / 'product')
(inputs / 'product/app.py').write_text('Disposable worker boundary canary.\n')
(inputs / 'source.md').write_bytes((study.HERE / 'requests/issue-10.md').read_bytes())
(inputs / 'accepted-input.md').write_text('The complete original request controls.\n')
(study.STORE / 'qualification').mkdir(exist_ok=True)
(study.STORE / 'qualification/sibling.txt').write_text('Private sibling canary.\n')
native = bound_module(boundaries, STORE=study.STORE)
native.read_protocol = lambda: {'model': study.protocol()['models']['ordinary']}
for worker in (False, True):
    native.boundary(inputs, directory / ('writable' if worker else 'readonly'), worker=worker)
# Actual nested protected grading once, without altering its launcher/protection.
reference = study.STORE / 'preflight/11/reference/product'
protected = study.oracle.observe(reference, 11, directory / 'protected-reference', seconds=60)
result = {'freeze_sha256': study.identities(), 'regressions': rows,
          'all_supplemental_controls_matched': all(row['observation']['matched'] for row in rows),
          'protected_observation': protected, 'elapsed_seconds': time.monotonic()-began,
          'model_dispatches': 0, 'execution_qualified': False,
          'status': 'NOT QUALIFIED',
          'blocker': 'Nested protected grading unavailable; independent exact-freeze review absent',
          'scope': __doc__}
write_record(directory / 'summary.json', result)
print(json.dumps({key: result[key] for key in ('freeze_sha256','all_supplemental_controls_matched',
 'elapsed_seconds','model_dispatches','execution_qualified','status','blocker')}))
