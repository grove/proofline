"""One model-free native observation with the existing trusted host runner.
This does not qualify the nested, candidate-owned CLI grading assembly.
"""
import hashlib
import json
from pathlib import Path
import sys
import time

from checks import host_probe as host, local_run
from checks.native_checks import write_record
from evaluation.checklist import study

began = time.monotonic()
root = study.STORE / 'native-demo'
root.mkdir(exist_ok=False)
task = next(t for t in study.protocol()['tasks'] if t['issue'] == 13)
product = study.existing.seed(task, root / 'product', reference=True)
source = (study.HERE / 'requests/issue-13.md').read_text()
line, clause = next((i, line) for i, line in enumerate(source.splitlines(), 1)
                    if line.startswith('- [ ] Report, **per supplied obligation**'))
python = str(Path(sys.executable).resolve())
checks = [[python, '-B', '-m', 'unittest', 'tests.test_promise_evidence', 'tests.test_feedback'],
          [python, '-B', '-c', 'raise AssertionError("deliberate negative control")'],
          [str(root / 'nonexistent-command')]]
mapping = {'schema_version': 1, 'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
           'requirements': [{'id': f'R{i+1}', 'statement': 'Observe the specified linked-command state (fixture only)',
                             'source_refs': [{'source_id': 'S1', 'line_start': line,
                                              'line_end': line, 'quote': clause}],
                             'checks': [{'index': i, 'argv': checks[i]}] if i < 3 else []}
                            for i in range(4)]}
before = host.snapshot(product)
report = local_run.check(product, source, checks, root / 'check', seconds=120, check_seconds=30,
                         promise_mapping=mapping)
readback = local_run.inspect(root / 'check/report.json')
write_record(root / 'readback.json', readback)
summary = {'status': report['status'], 'boundary': report.get('boundary', {}).get('assessment'),
           'observations': [row['status'] for row in report['observations']],
           'states': [row['status'] for row in report['promise_evidence']['requirements']],
           'readback_status': readback['status'], 'source_preserved': before == host.snapshot(product),
           'model_dispatches': report['model_dispatches'], 'elapsed_seconds': time.monotonic()-began,
           'scope': __doc__, 'freeze_sha256': study.identities()}
if report.get('observations') and report['observations'][0].get('receipt_ref'):
    receipt = root / 'check' / report['observations'][0]['receipt_ref']
    (root / 'original-receipt.json').write_bytes(receipt.read_bytes())
    receipt.write_text('{}\n')
    summary['tampered_readback_status'] = local_run.inspect(root / 'check/report.json')['status']
write_record(root / 'summary.json', summary)
print(json.dumps(summary))
assert summary['observations'] == ['PASSED', 'FAILED', 'UNAVAILABLE']
assert summary['states'] == ['LINKED CHECKS PASSED (limited evidence)', 'CHECK FAILED',
                             'CHECK UNAVAILABLE', 'NOT DEMONSTRATED']
assert summary['readback_status'] == 'CHECKS UNAVAILABLE'
assert summary['source_preserved'] and summary['model_dispatches'] == 0
assert summary['tampered_readback_status'] == 'STALE CHECKS'
