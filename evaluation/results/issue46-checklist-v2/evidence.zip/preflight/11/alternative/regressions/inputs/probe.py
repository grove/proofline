import json, unittest
suite = unittest.defaultTestLoader.loadTestsFromNames(['tests.test_check_only', 'tests.test_supported_cli', 'tests.test_candidate_snapshot'])
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({"tests": result.testsRun, "failures": len(result.failures), "errors": len(result.errors), "skipped": [[str(test), reason] for test, reason in result.skipped]}))
raise SystemExit(0 if result.wasSuccessful() else 1)
