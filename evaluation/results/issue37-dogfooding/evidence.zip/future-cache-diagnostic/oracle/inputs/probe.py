ALLOWED = (ValueError,TypeError,)
import copy, json, math, subprocess, sys, time
from pathlib import Path
from cache import Cache
from app import process
from service import handle

cases = []
def check(label, fn):
    try:
        fn()
        cases.append({'label':label,'passed':True})
    except Exception as error:
        cases.append({'label':label,'passed':False,
                      'error':type(error).__name__+': '+str(error)})
def eq(actual, expected):
    assert actual == expected, (actual, expected)
def rejects(call):
    try:
        call()
    except ALLOWED:
        return
    except Exception as error:
        raise AssertionError('unexpected TTL exception: '+type(error).__name__) from error
    raise AssertionError('invalid TTL was accepted')

def compatibility():
    cache = Cache(lambda:0)
    assert cache.get('old',lambda:1)==1
    assert cache.get('old',lambda:2)==1
    payload = {'actions':[{'op':'get','key':'x','value':1}]}
    eq(process(payload),{'values':[1],'loads':1})
    eq(handle(payload),{'values':[1],'loads':1})
    exe = str(Path(sys.modules['app'].__file__).resolve().parent/'/Users/grove/.p2p/issue37-20261014/future-cache-diagnostic/oracle/inputs/product/cli.py')
    command = subprocess.run([sys.executable,'-B',exe,'--version'],
                             capture_output=True,text=True,timeout=5)
    assert (command.returncode,command.stdout,command.stderr)==(0,'repo-v1\n','')
    command = subprocess.run([sys.executable,'-B',exe,'--unknown'],
                             capture_output=True,text=True,timeout=5)
    assert command.returncode==2
check('legacy compatibility', compatibility)

def actions():
    payload = {'actions':[{'op':'get','key':'x','value':1,'at':0,'ttl':2},
                          {'op':'get','key':'x','value':2,'at':2,'ttl':2},
                          {'op':'clear'}]}
    expected = {'values':[1,2,1],'loads':2}
    original = copy.deepcopy(payload)
    eq(process(payload),expected)
    eq(handle(payload),expected)
    assert payload==original
check('action example and seams',actions)

def expiry():
    clock=[10]; calls=[]; cache=Cache(lambda:clock[0])
    def loader():
        calls.append(1)
        return len(calls)
    assert cache.get('finite',loader,2)==1
    clock[0]=11; assert cache.get('finite',loader)==1 and len(calls)==1
    clock[0]=12; assert cache.get('finite',loader,2)==2
    clock[0]=20; assert cache.get('zero',loader,0)==3
    assert cache.get('zero',loader,0)==4
    cache.get('infinite',loader)
    clock[0]=1e6
    assert cache.get('infinite',loader)==5 and len(calls)==5
check('expiry and no-ttl behavior',expiry)

def copies():
    cache=Cache(lambda:0)
    input_value={'nested':[1]}
    first=cache.get('x',lambda:input_value)
    first['nested'].append(2)
    input_value['nested'].append(3)
    assert cache.get('x',lambda:None)=={'nested':[1]}
    second=cache.get('x',lambda:None)
    second['nested'].append(4)
    assert cache.get('x',lambda:None)=={'nested':[1]}
check('no aliased cache data',copies)

def invalidation():
    clock=[0]; cache=Cache(lambda:clock[0])
    cache.get('expired',lambda:1,1)
    clock[0]=2
    assert cache.invalidate('expired') is True
    assert cache.invalidate('expired') is False
    cache.get('a',lambda:2); cache.get('b',lambda:3)
    assert cache.clear()==2 and cache.clear()==0
check('invalidate expired and clear',invalidation)

for label, value in [
    ('reject TTL True',True),('reject TTL -1',-1),
    ('reject TTL nan',float('nan')),('reject TTL inf',float('inf')),
    ('reject TTL string','2'),
]:
    def invalid(value=value):
        calls=[]
        cache=Cache(lambda:0)
        cache.get('hit',lambda:1)
        rejects(lambda: cache.get('hit',lambda: calls.append(1),value))
        assert calls==[], 'invalid TTL invoked loader'
        rejects(lambda: cache.get('miss',lambda: calls.append(2),value))
        assert calls==[], 'invalid TTL invoked loader on miss'
    check(label,invalid)

def loader_failure():
    cache=Cache(lambda:0)
    loads=[]
    def failing():
        loads.append('fail')
        raise RuntimeError('loader')
    try:
        cache.get('key',failing)
    except Exception:
        pass  # Request promises no cache population, not an exception class.
    result=cache.get('key',lambda:loads.append('success') or 9)
    assert result==9 and loads==['fail','success']
check('loader failure does not populate cache',loader_failure)
import app
product_dir = str(Path(app.__file__).resolve().parent)
argv = [sys.executable,'-B','-m','unittest','discover','-s','tests']
receipt = {'argv':argv,'cwd':product_dir,'exit_code':None,
           'stdout':'','stderr':'','timed_out':False,
           'stdout_truncated':False,'stderr_truncated':False}
start = time.monotonic()
try:
    completed = subprocess.run(argv,cwd=product_dir,capture_output=True,
                               text=True,timeout=10)
    receipt['exit_code']=completed.returncode
    for name in ('stdout','stderr'):
        value=getattr(completed,name)
        receipt[name]=value[:8192]
        receipt[name+'_truncated']=len(value)>8192
except subprocess.TimeoutExpired as error:
    receipt['timed_out']=True
    for name in ('stdout','stderr'):
        value=getattr(error,name,None) or b''
        if isinstance(value,bytes):
            value=value.decode('utf-8',errors='replace')
        receipt[name]=value[:8192]
        receipt[name+'_truncated']=len(value)>8192
except OSError as error:
    receipt['error']=type(error).__name__+': '+str(error)
receipt['elapsed_seconds']=round(time.monotonic()-start,6)
unavailable = (receipt['exit_code'] is None or receipt['timed_out'] or
               receipt.get('error') or receipt['stdout_truncated'] or
               receipt['stderr_truncated'])
status = ('UNAVAILABLE' if unavailable else
          'PASSED' if receipt['exit_code']==0 else 'FAILED')
print(json.dumps({'cases':cases,'repository_tests':{
    'status':status,'passed':True if status=='PASSED' else
    False if status=='FAILED' else None,'receipt':receipt}},sort_keys=True))
