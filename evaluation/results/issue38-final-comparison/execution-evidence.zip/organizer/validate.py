import ast,hashlib,json,re,subprocess,tarfile,zipfile
from common import *
from checks.native_checks import write_record
frozen=json.loads((OUT/'input-hashes.json').read_text())
assert all(host.sha256(Path(p).read_bytes())==digest for p,digest in frozen.items())
assert host.snapshot(DEPS)['sha256']==json.loads((OUT/'environment.json').read_text())['dependency_snapshot_sha256']
results=json.loads((OUT/'results.json').read_text());rows=results['attempts'];protocol=json.loads((OUT/'protocol.json').read_text());grades=json.loads((OUT/'grades.json').read_text())['candidates']
assert len(rows)==4 and len({r['native_thread_id'] for r in rows})==4
assert [r['task']+':'+r['effort'] for r in rows]==protocol['order']
assert all(r['native_task_turns']==1 and r['worker_reported_completed'] for r in rows)
assert all(r['tokens']['input_tokens']-r['tokens']['cached_input_tokens']==r['uncached_input_tokens'] for r in rows)
reconstructed=[];bounds=[]
with zipfile.ZipFile(OUT/'execution-evidence.zip') as z:
    for r in rows:
        name=r['slot'];slug=r['task'];directory=STORE/'reconstruction'/name
        directory.mkdir(parents=True)
        with tarfile.open(OUT/f'{slug}-base.tar.gz') as archive:archive.extractall(directory,filter='data')
        host.git(directory,'init','--quiet','--template=')
        host.git(directory,'add','--force','--all')
        initial=host.git(directory,'write-tree');assert initial==r['initial_tree']
        patch=z.read(name+'/candidate.patch');assert host.sha256(patch)==r['patch_sha256']
        subprocess.run(['git','-C',str(directory),'apply','--binary','-'],input=patch,check=True)
        host.git(directory,'add','--force','--all');tree=host.git(directory,'write-tree');assert tree==r['candidate_tree']
        live=STORE/'attempts'/name/'implementation/inputs/product'
        assert host.git(live,'rev-parse','HEAD^{tree}')==tree
        assert host.git(live,'status','--porcelain')==''
        boundary=json.loads(z.read(name+'/boundary.json'));assert boundary['assessment']['status']=='OBSERVED'
        bounds.append(name)
        assert b'"type": "reasoning"' not in z.read(name+'/observations.json')
        assert r['coding_receipt']['prompt_sha256']==host.sha256(z.read(name+'/prompt.txt'))
        reconstructed.append({'slot':name,'initial_tree':initial,'candidate_tree':tree,'patch_sha256':host.sha256(patch)})
        grade=next(g for g in grades if g['slot']==name)
        assert grade['candidate_tree']==tree
        for kind,g in grade['observations'].items():
            assert g['available'] and g['inputs_unchanged']
            assert g['receipt']['exit_code']==(1 if slug=='boltons' and kind=='suite' else 0)
        argv=r['coding_receipt']['argv'];assert 'model="gpt-6-luna"' in argv and ('model_reasoning_effort="'+r['effort']+'"') in argv
    for slug in ('boltons','itsdangerous'):
        pair=[r for r in rows if r['task']==slug]
        prompts=[]
        for r in pair:
            text=z.read(r['slot']+'/prompt.txt').decode().replace(r['slot'],'SLOT')
            prompts.append(re.sub(r'You have at most [0-9.]+ seconds','You have at most BUDGET seconds',text))
        assert prompts[0]==prompts[1]
for p in OUT.glob('probe_*.py'):ast.parse(p.read_text())
controls=json.loads((OUT/'controls.json').read_text());assert controls['all_matched'] and len(controls['controls'])==8
for p in OUT.glob('*source-preflight.json'):assert json.loads(p.read_text())['qualification']['status']=='QUALIFIED'
review=json.loads((OUT/'supplementary-review-injected.json').read_text())['observations'];assert len(review)==5
for r in review:assert r['observation']['available'] and r['observation']['receipt']['exit_code']==(0 if r['name']=='baseline' else 1)
write_record(OUT/'validation.json',{'frozen_input_files_verified':len(frozen),'dependency_digest_unchanged':True,'fresh_contexts':4,'native_task_turns':4,'boundary_canaries_observed':bounds,'prompts_match_within_pairs_except_paths_and_remaining_time':True,'source_preflights_qualified':3,'control_outcomes_matched':8,'candidate_reconstructions':reconstructed,'protected_grades_available_and_bound':True,'supplementary_regression_observed_on_baseline_controls_and_both_candidates':True,'production_code_changes':0,'additional_model_dispatches':0})
print('Validated frozen inputs, dependencies, context/config matching, controls, receipts and four exact reconstructed candidate trees.')
