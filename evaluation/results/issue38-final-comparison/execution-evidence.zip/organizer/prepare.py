import hashlib,json,shutil,subprocess,time,platform,importlib.metadata
from pathlib import Path
from common import *
from evaluation.recovery.grader import invoke
from evaluation.source_preflight import qualify
from checks import candidate_snapshot as snapshots
from checks.native_checks import write_record
began=time.monotonic()
(OUT/'requests').mkdir(exist_ok=True)
tasks=[]
for slug,issue,repo in [('boltons',510,'mahmoud/boltons'),('itsdangerous',429,'pallets/itsdangerous')]:
    data=json.loads((STORE/f'{slug}-{issue}.json').read_text())
    source=data['title']+'\n\n'+data['body']+'\n'
    (OUT/'requests'/f'{slug}-{issue}.md').write_text(source)
    product=STORE/slug
    commit=host.git(product,'rev-parse','HEAD');tree=host.git(product,'rev-parse','HEAD^{tree}')
    subprocess.run(['git','-C',str(product),'archive','--format=tar.gz','-o',str(OUT/f'{slug}-base.tar.gz'),'HEAD'],check=True)
    tasks.append({'task':slug,'repository':repo,'issue':issue,'base':commit,'tree':tree,'source_sha256':host.sha256(source.encode())})
    r=invoke(product,suite(slug),STORE/'baseline-tests'/slug,seconds=90)
    write_record(OUT/f'baseline-tests-{slug}.json',r)
    print(slug,'baseline suite',r['available'],r['receipt'].get('exit_code'),r['receipt'].get('stdout'),r['receipt'].get('stderr'),flush=True)
# Non-model controls and declarations.
rows=[]
for task in tasks:
    slug=task['task']; product=STORE/slug
    script=header(slug)+(OUT/f'probe_{slug}.py').read_text()
    probes={'behavior':script}
    if slug=='itsdangerous': probes['typing']=header(slug)+(OUT/'probe_typing.py').read_text()
    source=(OUT/'requests'/f'{slug}-{task["issue"]}.md').read_bytes()
    clause=('The wrapped call should return the same result as the original.' if slug=='boltons' else 'I would still expect some kind of error or a warning on the line with `loads`;')
    inventory={'behavior':{'kind':'compatibility' if slug=='boltons' else 'negative','cases':(['original-collision','mixed-defaults-varargs-annotations','keyword-rejection','ordinary-signature-compatibility','positional-default-without-varargs'] if slug=='boltons' else ['untimed-max-age-error-or-warning','timed-expiry-and-timestamp-compatibility','salt-key-and-invalid-signature-compatibility'])}}
    decl={'schema_version':1,'study_id':'issue38-final-comparison','author':'organizer before dispatch','source_sha256':host.sha256(source),'oracle_sha256':host.sha256(script.encode()),'expectations':[{'id':'behavior','kind':inventory['behavior']['kind'],'cases':inventory['behavior']['cases'],'claim':clause,'support':'source','source_clause':clause,'ambiguity':'','acceptable_alternatives':['Equivalent behavior; no prescribed implementation','ItsDangerous allows warning or error of any class']}]}
    q=qualify(decl,source=source,oracle_text=script,inventory=inventory)
    assert q['status']=='QUALIFIED',q
    write_record(OUT/f'{slug}-source-preflight.json',{'declaration':decl,'inventory':inventory,'qualification':q})
    if slug=='itsdangerous':
        ts=probes['typing'];cl='Furthermore, the type checkers should warn the developer before they even run the code.'
        inv={'typing':{'kind':'compatibility','cases':['type-checker-flags-untimed-max-age','type-checker-allows-existing-timed-and-untimed-calls']}}
        d={**decl,'oracle_sha256':host.sha256(ts.encode()),'expectations':[{'id':'typing','kind':'compatibility','cases':inv['typing']['cases'],'claim':cl,'support':'source','source_clause':cl,'ambiguity':'','acceptable_alternatives':['Any static diagnostic on the unexpected argument; no exact wording']}]}
        tq=qualify(d,source=source,oracle_text=ts,inventory=inv); assert tq['status']=='QUALIFIED',tq
        write_record(OUT/'typing-source-preflight.json',{'declaration':d,'inventory':inv,'qualification':tq})
    for variant in ('baseline','reference','alternative','defective'):
        folder=STORE/'controls'/slug/variant; dest=folder/'product'
        shutil.copytree(product,dest,ignore=shutil.ignore_patterns('.git','__pycache__'))
        path=dest/('boltons/funcutils.py' if slug=='boltons' else 'src/itsdangerous/serializer.py')
        original=path.read_text();code=original
        if slug=='boltons':
            if variant in ('reference','defective'):
                code=code.replace('formatannotation=formatannotation):','formatannotation=formatannotation, posonlyargs=()):').replace('        specs.append(spec)\n    if varargs','        specs.append(spec)\n        if i + 1 == len(posonlyargs):\n            specs.append("/")\n    if varargs').replace('                                     annotations)','                                     annotations, posonlyargs=self.posonlyargs)')
            elif variant=='alternative':
                code=code.replace('        return inspect_formatargspec(self.args,','        args = list(self.args)\n        if self.posonlyargs:\n            args.insert(len(self.posonlyargs), "/")\n        return inspect_formatargspec(args,')
            if variant=='defective':code=code.replace('and arg not in self.posonlyargs','and True')
        else:
            if variant=='reference':code=code.replace('salt: str | bytes | None = None, **kwargs: t.Any\n    ) -> t.Any:', 'salt: str | bytes | None = None\n    ) -> t.Any:')
            elif variant=='alternative':
                code=code.replace('**kwargs: t.Any\n    ) -> t.Any:', '**kwargs: t.NoReturn\n    ) -> t.Any:')
                code=code.replace('        s = want_bytes(s)\n        last_exception', '        if kwargs:\n            raise ValueError("unexpected keyword arguments")\n        s = want_bytes(s)\n        last_exception')
            elif variant=='defective':
                # Runtime rejection with a permissive annotation misses the requested typing protection.
                code=code.replace('        s = want_bytes(s)\n        last_exception', '        if kwargs:\n            raise ValueError("unexpected keyword arguments")\n        s = want_bytes(s)\n        last_exception')
        if variant!='baseline':assert code!=original,(slug,variant)
        path.write_text(code)
        host.git(dest,'init','--quiet','--template=');snapshots.freeze(dest)
        outcomes={key:invoke(dest,value,folder/key,seconds=45) for key,value in probes.items()}
        passed=all(r['available'] and r['receipt']['exit_code']==0 for r in outcomes.values())
        row={'task':slug,'variant':variant,'expected_pass':variant in ('reference','alternative'),'passed':passed,'observations':outcomes}
        row['matched']=all(r['available'] for r in outcomes.values()) and passed==row['expected_pass']; rows.append(row)
        print(slug,variant,row['matched'],[(k,r['receipt'].get('exit_code'),r['receipt'].get('stdout')[-1200:],r['receipt'].get('stderr')[-500:]) for k,r in outcomes.items()],flush=True)
        (folder/'control.patch').write_bytes(subprocess.check_output(['git','diff','--no-index','--',str(product/path.relative_to(dest)),str(path)])) if False else None
write_record(OUT/'controls.json',{'model_dispatches':0,'all_matched':all(r['matched'] for r in rows),'controls':rows})
write_record(OUT/'environment.json',{'python':sys.version,'python_executable':PY,'host':platform.platform(),'codex':'0.163.0','dependency_directory':str(DEPS),'dependency_snapshot_sha256':host.snapshot(DEPS)['sha256'],'versions':{d.metadata['Name']:d.version for d in importlib.metadata.distributions(path=[str(DEPS)])},'preparation_elapsed_seconds':time.monotonic()-began})
write_record(OUT/'protocol.json',{'study':'issue38-final-comparison','declared_before_dispatch':True,'tasks':tasks,'order':['boltons:medium','boltons:high','itsdangerous:high','itsdangerous:medium'],'model':'gpt-6-luna','seconds_per_attempt':900,'attempts':4,'retries':0,'authorization':'Current user request explicitly authorizes final four attempts and draft PR; existing subscription only, no paid API/fallback.','backend_identity':'UNKNOWN','billing_usd':'UNKNOWN','isolation':'Existing native profile with only dedicated dependency directory added read-only. No network, plugins, memories, delegation, grader or sibling access.','source_exposure':'Public issues; possible public solutions/training exposure UNKNOWN. Neither used as prior Proofline coding assignment.','stop_rule':'No retries or arm escalation. Retain all attempts; stop if native boundary fails or subscription unavailable.'})
assert all(r['matched'] for r in rows)
