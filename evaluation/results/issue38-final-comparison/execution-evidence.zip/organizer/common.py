import sys
from pathlib import Path
from checks import host_probe as host
ROOT=Path('/Users/grove/projects/proofline')
STORE=Path('/private/tmp/proofline-issue38-final')
OUT=ROOT/'evaluation/results/issue38-final-comparison'
DEPS=STORE/'deps'
original_profile=host.permission_profile
def profile(inputs,scratch,private):
    p=original_profile(inputs,scratch,private)
    p['filesystem'][str(DEPS)]='read'
    return p
host.permission_profile=profile
PY= str(Path(sys.executable).resolve())
def header(slug):
    return 'import sys,os\nfrom pathlib import Path\np=Path(sys.path[0])\nsys.path[:0]=['+repr(str(DEPS))+',str(p / "src"),str(p)]\nos.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"]="1"\n'
def suite(slug):
    args=['-q','-p','no:cacheprovider','--basetemp='+str(STORE/'unused')]
    # Scratch cwd is unique and writable; repository and dependencies stay read-only.
    return header(slug)+'import pytest\nargs='+repr(['-q','-p','no:cacheprovider'])+'+["--basetemp="+os.getcwd()+"/pytest",str(p / "tests")]\n'+ ('args += ["--doctest-modules", str(p / "boltons")]\n' if slug=='boltons' else '') +'raise SystemExit(pytest.main(args))\n'
