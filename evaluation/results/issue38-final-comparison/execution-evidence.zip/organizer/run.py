import json,time,hashlib
from common import *
from checks import coding_attempt
from checks.native_checks import write_record
protocol=json.loads((OUT/'protocol.json').read_text())
assert json.loads((OUT/'controls.json').read_text())['all_matched']
for slug in ('boltons','itsdangerous'):
    g='Use the existing test suite and add focused regressions for the original request. Dependencies are installed and mounted read-only at '+str(DEPS)+'. Network is disabled. From the product root use PYTHONPATH='+str(DEPS)+':src:. python3 -m pytest -q -p no:cacheprovider --basetemp="$TMPDIR/pytest". '
    if slug=='boltons':
        g+='Baseline full tests plus doctests: 676 passed, 12 subtests passed; two socket tests fail because network is disabled. Preserve isolation; test_funcutils.py and test_funcutils_fb_py3.py are available. '
    else:
        g+='Baseline: all 297 tests pass. Pyright is available using /opt/homebrew/bin/node '+str(DEPS)+'/pyright/dist/index.js --pythonpath '+PY+'. '
    g+='Keep generated caches in scratch. Do not change tests to hide existing behavior or failures.\n'
    (OUT/f'guidance-{slug}.txt').write_text(g)
files=[p for p in OUT.rglob('*') if p.is_file()]
files += [STORE/'common.py',STORE/'prepare.py',Path(__file__).resolve()]
write_record(OUT/'input-hashes.json',{str(p):host.sha256(p.read_bytes()) for p in files})
# Fixed task, order, limits, source checks and controls are now frozen before any coding call.
for i,pair in enumerate(protocol['order'],1):
    slug,effort=pair.split(':');task=next(t for t in protocol['tasks'] if t['task']==slug)
    name=f'{i:02}-{slug}-{effort}';directory=STORE/'attempts'/name
    assert not directory.exists(),'No reruns'
    directory.mkdir(parents=True)
    began=time.monotonic()
    result=coding_attempt.run(STORE/slug,(OUT/'requests'/f'{slug}-{task["issue"]}.md').read_text(),(OUT/f'guidance-{slug}.txt').read_text(),directory,'/opt/homebrew/bin/codex',{'model':'gpt-6-luna','model_reasoning_effort':effort},900,'Python is python3. Ordinary dependencies are in the read-only directory described in guidance.')
    result['total_seconds']=time.monotonic()-began
    write_record(directory/'result.json',result)
    print(name,result.get('accepted'),result.get('model_dispatches'),round(result['total_seconds'],3),flush=True)
    if not result.get('stages') or result['stages'][0].get('status')!='OBSERVED':
        raise RuntimeError('Unavailable attempt retained; stop without retry')
