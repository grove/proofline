import collections,json,subprocess,zipfile,time
from common import *
from checks.native_checks import write_record
protocol=json.loads((OUT/'protocol.json').read_text());grades={r['slot']:r for r in json.loads((OUT/'grades.json').read_text())['candidates']}
rows=[]
with zipfile.ZipFile(OUT/'execution-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for folder in sorted((STORE/'attempts').iterdir()):
        name=folder.name;_,slug,effort=name.split('-')
        r=json.loads((folder/'result.json').read_text());s=r['stages'][0];p=Path(r['candidate']);priv=folder/'implementation/private'
        events=[json.loads(x) for x in (priv/'events.jsonl').read_text().splitlines()]
        tools=[e['item'] for e in events if e['type']=='item.completed' and e['item']['type'] in ('command_execution','file_change')]
        initial=host.git(p,'rev-parse','HEAD^');tree=host.git(p,'rev-parse','HEAD^{tree}');bt=host.git(p,'rev-parse','HEAD^^{tree}')
        task=next(t for t in protocol['tasks'] if t['task']==slug);assert bt==task['tree']
        assert grades[name]['candidate_tree']==tree
        changed=host.git(p,'diff','--name-only',initial,'HEAD').splitlines()
        patch=subprocess.check_output(['git','-C',str(p),'diff','--binary',initial,'HEAD'])
        selfchecks=[c for c in s['commands'].values() if any(w in c['command'] for w in ('python','pytest','pyright','diff --check'))]
        row={'slot':name,'task':slug,'effort':effort,'requested_model':'gpt-6-luna','backend_identity':'UNKNOWN','status':'FINISHED','assessment':('CONFIRMED_COMPATIBILITY_REGRESSION' if slug=='boltons' else 'INDEPENDENTLY_SUPPORTED_CORRECT_DELIVERY'),'worker_reported_completed':r['accepted'],'candidate_commit':host.git(p,'rev-parse','HEAD'),'candidate_tree':tree,'base_commit_original':task['base'],'initial_snapshot_commit':initial,'initial_tree':bt,'patch_sha256':host.sha256(patch),'changed_files':changed,'attempt_seconds':r['total_seconds'],'native_coding_seconds':s['receipt']['elapsed_seconds'],'grading_elapsed_seconds':grades[name]['grading_elapsed_seconds'],'native_thread_id':s['thread_id'],'native_task_turns':sum(e['type']=='turn.started' for e in events),'backend_model_requests':'UNKNOWN','tool_calls':len(tools),'command_executions':sum(t['type']=='command_execution' for t in tools),'file_change_calls':sum(t['type']=='file_change' for t in tools),'tokens':s['usage'],'uncached_input_tokens':s['usage']['input_tokens']-s['usage']['cached_input_tokens'],'billing_usd':'UNKNOWN','human_interventions':0,'handoff':s['report'],'self_checks':selfchecks,'coding_receipt':s['receipt']}
        rows.append(row)
        z.writestr(name+'/candidate.patch',patch)
        z.writestr(name+'/tree-manifest.nul',subprocess.check_output(['git','-C',str(p),'ls-tree','-rz','HEAD']))
        for file in ['prompt.txt','stderr.txt','worker.json']:z.write(priv/file,name+'/'+file)
        for file in ['source.md','guidance.md']:z.write(folder/'implementation/inputs'/file,name+'/'+file)
        z.write(folder/'preflight/report.json',name+'/boundary.json')
        observed=[e for e in events if e['type'] in ('thread.started','turn.started','turn.completed','turn.failed','error') or e['type']=='item.completed' and e['item']['type'] in ('command_execution','file_change','agent_message')]
        z.writestr(name+'/observations.json',json.dumps(observed,indent=2)+'\n')
        z.writestr(name+'/result.json',json.dumps(row,indent=2)+'\n')
    for f in ['common.py','prepare.py','run.py','grade.py','review_probe.py','prepare-final.log','run.log']:
        z.write(STORE/f,'organizer/'+f)
    for slug,path in [('boltons','boltons/funcutils.py'),('itsdangerous','src/itsdangerous/serializer.py')]:
        for variant in ('reference','alternative','defective'):
            a=(STORE/slug/path).read_text();b=(STORE/'controls'/slug/variant/'product'/path).read_text()
            import difflib
            patch=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
            z.writestr(f'controls/{slug}-{variant}.patch',patch)
old=json.loads((ROOT/'evaluation/results/issue38-two-task-pilot/results.json').read_text())['attempts']
def totals(rs):
    return {effort:{'attempts':len([r for r in rs if r['effort']==effort]),'supported_correct':sum(r['assessment']=='INDEPENDENTLY_SUPPORTED_CORRECT_DELIVERY' for r in rs if r['effort']==effort),'attempt_seconds':sum(r['attempt_seconds'] for r in rs if r['effort']==effort),'native_coding_seconds':sum(r['native_coding_seconds'] for r in rs if r['effort']==effort),'tool_calls':sum(r['tool_calls'] for r in rs if r['effort']==effort),'uncached_input_tokens':sum(r['uncached_input_tokens'] for r in rs if r['effort']==effort),'tokens':{k:sum(r['tokens'][k] for r in rs if r['effort']==effort) for k in ('input_tokens','cached_input_tokens','cache_write_input_tokens','output_tokens','reasoning_output_tokens')}} for effort in ('medium','high')}
record={'study':protocol['study'],'model_dispatches':4,'attempts':rows,'new_totals':totals(rows),'combined_with_pilot':totals(old+rows),'decision':'MEDIUM PREFERRED','decision_scope':'Pragmatic default for similarly scoped work; equal observed correctness including a shared compatibility defect, and lower observed coding time. Not a dollar-cost or general-reliability claim.','billing_usd':'UNKNOWN','human_interventions':0,'organizer_time_tokens_and_human_time':'UNKNOWN'}
write_record(OUT/'results.json',record)
print(json.dumps({k:record[k] for k in ('new_totals','combined_with_pilot')},indent=2))
