import json
from boltons.funcutils import wraps
# Existing documented injected= API must retain the remaining ordinary c keyword.
def original(a, b, /, c=3):
    return a, b, c
@wraps(original, injected='a')
def wrapped(*args, **kwargs):
    return original(100, *args, **kwargs)
try:
    result=wrapped(2, c=4)
    assert result==(100,2,4),result
    print(json.dumps({'passed':True,'result':result,'generated_source':wrapped.__source__}))
except Exception as error:
    print(json.dumps({'passed':False,'error':repr(error),'generated_source':wrapped.__source__}))
    raise
