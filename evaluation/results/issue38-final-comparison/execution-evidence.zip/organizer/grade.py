import json,time
from common import *
from evaluation.recovery.grader import invoke
from checks.native_checks import write_record
rows=[]
for folder in sorted((STORE/'attempts').iterdir()):
    result=json.loads((folder/'result.json').read_text());slug=folder.name.split('-')[1];p=Path(result['candidate'])
    name=folder.name;began=time.monotonic()
    scripts={'behavior':header(slug)+(OUT/f'probe_{slug}.py').read_text(),'suite':suite(slug)}
    if slug=='itsdangerous':scripts['typing']=header(slug)+(OUT/'probe_typing.py').read_text()
    outcomes={k:invoke(p,s,STORE/'grades'/name/k,seconds=90) for k,s in scripts.items()}
    row={'slot':name,'candidate_tree':host.git(p,'rev-parse','HEAD^{tree}'),'observations':outcomes,'grading_elapsed_seconds':time.monotonic()-began}
    for k,r in outcomes.items():
        dest=STORE/'grades'/name/k/'inputs/product'
        assert host.git(dest,'rev-parse','HEAD^{tree}')==row['candidate_tree']
        print(name,k,r['available'],r['receipt'].get('exit_code'),r['receipt'].get('stdout')[-1300:],r['receipt'].get('stderr')[-400:],flush=True)
    rows.append(row)
write_record(OUT/'grades.json',{'model_dispatches':0,'candidates':rows})
