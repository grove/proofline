Keep this complete original request.
Retain Unicode: José.
