Complete original request canary.
