import sys,runpy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'tool'))
runpy.run_module('intentline',run_name='__main__')
