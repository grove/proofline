import json
from pathlib import Path
from checks import candidate_snapshot as snapshots,host_probe as host
from evaluation.recovery import grader
from evaluation.sol_luna.grader import bound_module

root=Path.cwd();base=root/'.proofline/issue52-phase3-click'
source=(base/'src/click/formatting.py').read_text()
# These are trusted evaluator controls, never a worker solution or oracle approval.
reference=source.replace('    preserve_paragraphs: bool = False,\n','    preserve_paragraphs: bool = False,\n    break_on_hyphens: bool = True,\n',1).replace('        replace_whitespace=False,\n','        replace_whitespace=False,\n        break_on_hyphens=break_on_hyphens,\n',1)
a=reference.index('    def write_usage(');b=reference.index('    def write_heading(',a)
segment=reference[a:b]
first='                    subsequent_indent=indent,\n'
second='                    args, text_width, initial_indent=indent, subsequent_indent=indent\n'
assert segment.count(first)==1 and segment.count(second)==1
fixed=segment.replace(first,first+'                    break_on_hyphens=False,\n').replace(second,'                    args, text_width, initial_indent=indent, subsequent_indent=indent,\n                    break_on_hyphens=False,\n')
defective=reference[:a]+segment.replace(first,first+'                    break_on_hyphens=False,\n')+reference[b:]
reference=reference[:a]+fixed+reference[b:]
a=source.index('    def write_usage(');b=source.index('    def write_heading(',a)
segment=source[a:b]
anchor='        if prefix is None:\n'
helper='''        from ._textwrap import TextWrapper

        def wrap_usage(text, width, initial_indent, subsequent_indent):
            return TextWrapper(width, initial_indent=initial_indent,
                               subsequent_indent=subsequent_indent,
                               replace_whitespace=False,
                               break_on_hyphens=False).fill(text.expandtabs())

'''
assert segment.count(anchor)==1
alternative=source[:a]+segment.replace(anchor,helper+anchor,1).replace('wrap_text(', 'wrap_usage(')+source[b:]
controls={'task':'click-usage-hyphens','independent_review':'PENDING','whole_source_correct':None,'path':'src/click/formatting.py','base_sha256':host.sha256(source.encode()),'variants':{}}
for name,new in [('reference',reference),('alternative',alternative),('defective-second-layout',defective)]:
 controls['variants'][name]={'old':source,'new':new,'new_sha256':host.sha256(new.encode())}
(root/'evaluation/issue52/fresh-controls.json').write_text(json.dumps(controls,indent=2)+'\n')
print('Authored 2 positive controls and 1 deliberate second-layout omission; review pending.')
