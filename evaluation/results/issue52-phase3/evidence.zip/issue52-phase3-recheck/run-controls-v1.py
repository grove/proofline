import json,os,subprocess,time,signal
from pathlib import Path
from checks import candidate_snapshot as snapshots,host_probe as host
from evaluation.recovery import grader
from evaluation.sol_luna.grader import bound_module
root=Path.cwd();out=root/'.proofline/issue52-phase3-controls';out.mkdir(exist_ok=False)
controls=json.loads((root/'evaluation/issue52/fresh-controls.json').read_text())
private=bound_module(grader,CODEX=str(root/'.proofline/issue52-phase3-tools/codex'))
program=(root/'evaluation/issue52/fresh_oracles.py').read_text().split("if __name__ == '__main__':")[0]+"\nusage_tokens()\nprint(json.dumps({'probe_passed': True, 'whole_source_correct': None, 'independent_review': 'PENDING'}))\n"
results={'model_dispatches':0,'live_dispatch_allowed':False,'independent_review':'PENDING','whole_source_correct':None,'controls':[]}
for variant in ['original','reference','alternative','defective-second-layout']:
 folder=out/variant;folder.mkdir();product=folder/'product'
 snapshots.capture_base(root/'.proofline/issue52-phase3-click',product)
 if variant!='original':
  patch=root/controls['variants'][variant]['patch_file'];subprocess.run(['git','apply',str(patch)],cwd=product,check=True)
 snapshots.freeze(product)
 observation=private.invoke(product,program,folder/'oracle',trusted=False,seconds=30)
 row={'variant':variant,'candidate_tree':host.git(product,'rev-parse','HEAD^{tree}'),'observation':observation,'matched':observation['available'] and ((observation['receipt']['exit_code']==0)==(variant in ['reference','alternative']))}
 if variant=='defective-second-layout':
  argv=[str(root/'.proofline/issue52-phase3-python/bin/python'),'-B','-m','pytest','-q','--basetemp='+str(folder/'pytest-tmp')]
  start=time.monotonic();p=subprocess.Popen(argv,cwd=product,env={**os.environ,'PYTHONPATH':str(product/'src'),'PYTHONDONTWRITEBYTECODE':'1'},capture_output=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
  timed=False
  try:a,b=p.communicate(timeout=180)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGKILL);a,b=p.communicate()
  row['existing_suite']={'argv':argv,'exit_code':p.returncode,'timed_out':timed,'stdout':a,'stderr':b,'elapsed_seconds':time.monotonic()-start,'native_sandbox':False,'scope':'Trusted authored control only; complete original default suite, no changed tests.'}
 results['controls'].append(row);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(variant,row['matched'],observation['receipt'].get('exit_code'),flush=True)
