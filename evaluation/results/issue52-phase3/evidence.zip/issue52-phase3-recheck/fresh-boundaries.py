import json,sys
from pathlib import Path
from checks import host_probe as host,codex_live as live,candidate_snapshot as snapshots
from checks.native_checks import write_record
root=Path.cwd();out=root/'.proofline/issue52-phase3-fresh-oracle-boundaries';out.mkdir(exist_ok=False)
inputs=out/'inputs';(inputs/'product').mkdir(parents=True);(inputs/'product/app.py').write_text('Original canary')
host.git(inputs/'product','init','--quiet','--template=');snapshots.freeze(inputs/'product');(inputs/'source.md').write_text('Complete source')
codex=str(root/'.proofline/issue52-phase3-tools/codex');observed={}
for role in ['grader','worker']:
 directory=out/role;directory.mkdir()
 denied={'fresh_oracle':str(root/'evaluation/issue52/fresh_oracles.py'),'reference_control':str(root/'evaluation/issue52/fresh-controls/reference.patch'),'alternative_control':str(root/'evaluation/issue52/fresh-controls/alternative.patch'),'source_inventory':str(root/'evaluation/issue52/COHORT-REVIEW.md'),'cohort':str(root/'evaluation/issue52/candidate-cohort.json'),'sibling_observation':str(root/'.proofline/issue52-phase3-controls-v3/results.json')}
 with host.boundary_fixture(directory,inputs,target=inputs/'product/app.py',denied_reads=denied) as (spec,before,private_before,_):
  argv=host.sandbox_argv(codex,inputs,directory/'scratch',directory/'private')
  if role=='worker':
   command=live.command(codex,inputs,directory/'scratch',directory/'private',{'model':'gpt-6-luna','model_reasoning_effort':'medium'},implementer=True)
   profile=next(v for v in command if v.startswith('permissions.proofline='))
   argv=[codex,'--no-daemon','-c',profile,'sandbox','--permission-profile','proofline','--include-managed-config','--cd',str(directory/'scratch'),'--',str(Path(sys.executable).resolve()),'-I','-B',str(inputs/'canary.py'),str(inputs/'canary.json')]
  receipt=host.run_command(argv,directory/'scratch',15)
 if role=='grader':
  assessment=host.assess_canary(receipt,spec,before==host.snapshot(inputs) and private_before==host.snapshot(directory/'private'))
 else:
  item=json.loads(receipt['stdout']) if host.succeeded(receipt) else {}
  writes=dict.fromkeys(spec['writes'],'denied');writes['candidate']='allowed'
  after=host.snapshot(inputs);unchanged=all(e==after['entries'][i] for i,e in enumerate(before['entries']) if e['path']!='product/app.py')
  valid=item.get('nonce')==spec['nonce'] and item.get('reads')==dict.fromkeys(spec['reads'],'denied') and item.get('writes')==writes and item.get('network')=='denied' and item.get('mode_change')=='allowed' and item.get('scratch') is True and unchanged and private_before==host.snapshot(directory/'private')
  assessment={'status':'OBSERVED' if valid else 'NOT VERIFIED','observations':item}
 observed[role]={'receipt':receipt,'assessment':assessment}
 write_record(directory/'boundary.json',observed[role])
 assert assessment['status']=='OBSERVED',observed[role]
 for name in ['canary.py','canary.json']:(inputs/name).unlink()
write_record(out/'results.json',{'model_dispatches':0,'live_dispatch_allowed':False,'boundaries':observed,'status':'FINITE_FRESH_ORACLE_CANARIES_OBSERVED'})
print('Both profiles deny the actual new oracle, both positive controls, source inventory, cohort and sibling results; zero model turns.')
